import math_operations 

print(math_operations.add(5, 2))
print(math_operations.subract(5, 2))