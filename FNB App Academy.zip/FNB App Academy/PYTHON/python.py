#Numeric data
num = 3
print(type(num))

num2 = 3.14
print(type(num2))


#Variables
my_variable = 10
total_count = 0
user = 'John'


#Operators
#Additopn (+)
#Subtraction (-)
#Multiplication (*)
#Division (/)
#Modulus (%)
#Exponent (* *)

x = 10
x -=2

print(x)


#Operators with Strings
str1 = 'Hello'
str2 = 'World'

print(str1 * 3)


#Control Statements 
num = -5

if num > 20:
    print("This number is positive")
elif num == 0:
    print("This number is zero")
else:
    print("This is either zero or negative")


number1 = int(input("Enter the first number: "))
number2 = int(input("Enter the second number: "))

if number1 > number2:
    print(number1, "is greater than", number2)
elif number2 > number1:
    print(number 2, "is greather than", number1)
else:
    print("Both numbers are equal")


#Loops
count = 0

while count < 5:
    print(count)
    count += 1
    if count == 3:
        break #Exists the loop when it reaches 3