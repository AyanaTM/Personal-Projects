
def area(length, width):
    #Function to calculate area
    return length * width

def perimeter(length, width):
    #Function to calculate the perimeter
    return 2 * (length + width)