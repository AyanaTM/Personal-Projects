#Create a shopping cart programme that will continuously ask the user for a food product and the price of that product.
#Have an exit clause if the user wishes to stop adding more things to their cart.
#At the end of the food items and the total cost to the user.

food = []
price = []
total_cost = []

while True:
    foods = input("Enter a food to buy or ppress q to quit: ")
    if foods.lower() == 'q':
        break
    else:
        prices = float(input(f"Enter the price of the {food}: R"))
        food.append(foods)
        price.append(prices)

print("----- YOUR CART -----")

for foods in food:
    print(foods)

for prices in price:
    total_cost += prices
    

