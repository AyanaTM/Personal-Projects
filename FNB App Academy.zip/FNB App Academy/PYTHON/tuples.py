#Tuples 
my_tuples = (1, 2, 3, 4, 5)

print(my_tuples)
print(my_tuples[0])
print(my_tuples[2])
print(my_tuples[-1])

tuple1 = (1, 2, 3)
tuple2 = (4, 5, 6)

conc_tuple = tuple1 + tuple2
rep_tuple = tuple1 * 3

print(conc_tuple)
print(rep_tuple)