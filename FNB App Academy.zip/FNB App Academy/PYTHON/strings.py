#Advanced concepts - Strings

message = ' Hello, World! '
print(message.strip()) #remove leading and trailing whitespace
print(message.lower()) #Convert all characters to lowercase
print(message.split(',')) #Split the string into a ist based on the comma

