#Operators

#Additopn (+)
#Subtraction (-)
#Multiplication (*)
#Division (/)
#Modulus (%)
#Exponent (* *)

'''
x = 10
y = 2

print(x+y)
print(x-y)
print(x*y)
print(x/y)
print(x%y)
print(5%2)
print(x**y)
'''

x = 10
x -= 2

print(x)