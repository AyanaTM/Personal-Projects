﻿using MunicipalServicesApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp.Services
{
    /// <summary>
    /// Static class to manage in-memory storage of municipal issues
    /// Implements community engagement tracking features
    /// </summary>
    public static class DataManager
    {
        private static List<Issue> issues = new List<Issue>();
        private static int nextIssueId = 1001; // Start with professional ID numbers

        /// <summary>
        /// Adds a new issue to the system and returns the assigned ID
        /// </summary>
        /// <param name="issue">The issue to add</param>
        /// <returns>The auto-generated issue ID</returns>
        public static int AddIssue(Issue issue)
        {
            issue.IssueId = nextIssueId++;
            issue.SubmissionDate = DateTime.Now;
            issues.Add(issue);
            return issue.IssueId;
        }

        /// <summary>
        /// Retrieves all submitted issues
        /// </summary>
        /// <returns>List of all issues</returns>
        public static List<Issue> GetAllIssues()
        {
            return new List<Issue>(issues); // Return copy to prevent external modification
        }

        /// <summary>
        /// Gets the total count of issues submitted today (for engagement metrics)
        /// </summary>
        /// <returns>Number of issues submitted today</returns>
        public static int GetTodayIssueCount()
        {
            return issues.Count(i => i.SubmissionDate.Date == DateTime.Today);
        }

        /// <summary>
        /// Gets the total count of all issues (for community impact display)
        /// </summary>
        /// <returns>Total number of issues</returns>
        public static int GetTotalIssueCount()
        {
            return issues.Count;
        }

        /// <summary>
        /// Gets issues by category for community engagement insights
        /// </summary>
        /// <param name="category">The category to filter by</param>
        /// <returns>List of issues in the specified category</returns>
        public static List<Issue> GetIssuesByCategory(string category)
        {
            return issues.Where(i => i.Category.Equals(category, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>
        /// Updates the status of an issue (for future administrative features)
        /// </summary>
        /// <param name="issueId">ID of the issue to update</param>
        /// <param name="newStatus">New status to set</param>
        /// <returns>True if update successful, false otherwise</returns>
        public static bool UpdateIssueStatus(int issueId, string newStatus)
        {
            Issue issue = issues.FirstOrDefault(i => i.IssueId == issueId);
            if (issue != null)
            {
                issue.Status = newStatus;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Gets issues filtered by status for administrative views
        /// </summary>
        /// <param name="status">Status to filter by</param>
        /// <returns>List of issues with specified status</returns>
        public static List<Issue> GetIssuesByStatus(string status)
        {
            return issues.Where(i => i.Status.Equals(status, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>
        /// Gets summary statistics for community engagement dashboard
        /// </summary>
        /// <returns>A dictionary containing issue counts by category and status</returns>
        public static Dictionary<string, int> GetSummaryStatistics()
        {
            var stats = new Dictionary<string, int>();
            stats["TotalIssues"] = issues.Count;
            stats["TodayIssues"] = issues.Count(i => i.SubmissionDate.Date == DateTime.Today);
            // Category counts
            foreach (var category in issues.Select(i => i.Category).Distinct())
            {
                stats[$"Category_{category}"] = issues.Count(i => i.Category == category);
            }
            // Status counts
            foreach (var status in issues.Select(i => i.Status).Distinct())
            {
                stats[$"Status_{status}"] = issues.Count(i => i.Status == status);
            }
            return stats;
            //(Microsoft, 2024)
            //(Microsoft, 2024 & Validation Techniques in C#, 2022)
        }

    }
}
/*
Reference List
1. Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 07 September 2025]. 
2. Validation Techniques in C#. 2022. In: Smith, J. and Lee, A. eds. Programming best practices. Johannesburg: CodePress, Chapter 7: 112-130.
*/
