﻿using MunicipalServicesApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp.Services
{
    /// <summary>
    /// Manages events using advanced data structures:
    /// - SortedDictionary for efficient date-based organization
    /// - HashSet for unique categories and tags
    /// - Priority Queue for urgent announcements
    /// - Dictionary for category-based indexing
    /// - Stack for tracking user search history
    /// - Queue for managing event notifications
    /// </summary>
    public static class EventManager
    {
        // SortedDictionary: Events organized by date (automatically sorted)
        private static SortedDictionary<DateTime, List<Event>> eventsByDate = new SortedDictionary<DateTime, List<Event>>();

        // Dictionary: Fast lookup by category
        private static Dictionary<string, List<Event>> eventsByCategory = new Dictionary<string, List<Event>>();

        // HashSet: Unique categories and tags for filtering
        private static HashSet<string> allCategories = new HashSet<string>();
        private static HashSet<string> allTags = new HashSet<string>();

        // Priority Queue implementation using SortedSet
        private static SortedSet<Event> priorityEvents = new SortedSet<Event>(new EventPriorityComparer());

        // Stack: User search history (LIFO - Last In First Out)
        private static Stack<string> searchHistory = new Stack<string>();

        // Queue: Event notification queue (FIFO - First In First Out)
        private static Queue<Event> notificationQueue = new Queue<Event>();

        // Counter for event IDs
        private static int nextEventId = 2001;

        // Static flag to ensure initialization happens only once
        private static bool isInitialized = false;

        static EventManager()
        {
            Initialize();
        }

        /// <summary>
        /// Initialize the EventManager (called automatically via static constructor)
        /// </summary>
        public static void Initialize()
        {
            if (!isInitialized)
            {
                InitializeDataStructures();
                LoadSampleEvents();
                isInitialized = true;
            }
        }

        private static void InitializeDataStructures()
        {
            eventsByDate = new SortedDictionary<DateTime, List<Event>>();
            eventsByCategory = new Dictionary<string, List<Event>>();
            allCategories = new HashSet<string>();
            allTags = new HashSet<string>();
            priorityEvents = new SortedSet<Event>(new EventPriorityComparer());
            searchHistory = new Stack<string>();
            notificationQueue = new Queue<Event>();
        }

        /// <summary>
        /// Adds a new event and updates all data structures
        /// </summary>
        public static int AddEvent(Event evt)
        {
            evt.EventId = nextEventId++;
            evt.CreatedDate = DateTime.Now;

            // Add to sorted dictionary by date
            DateTime dateKey = evt.EventDate.Date;
            if (!eventsByDate.ContainsKey(dateKey))
            {
                eventsByDate[dateKey] = new List<Event>();
            }
            eventsByDate[dateKey].Add(evt);

            // Add to category dictionary
            if (!eventsByCategory.ContainsKey(evt.Category))
            {
                eventsByCategory[evt.Category] = new List<Event>();
            }
            eventsByCategory[evt.Category].Add(evt);

            // Add category and tags to sets
            allCategories.Add(evt.Category);
            foreach (string tag in evt.Tags)
            {
                allTags.Add(tag);
            }

            // Add to priority queue if high priority or urgent
            if (evt.Priority >= EventPriority.High)
            {
                priorityEvents.Add(evt);
            }

            // Add to notification queue
            notificationQueue.Enqueue(evt);

            return evt.EventId;
        }

        /// <summary>
        /// Gets all events in chronological order (using SortedDictionary)
        /// </summary>
        public static List<Event> GetAllEvents()
        {
            List<Event> allEvents = new List<Event>();
            foreach (var dateEntry in eventsByDate)
            {
                allEvents.AddRange(dateEntry.Value);
            }
            return allEvents;
        }

        /// <summary>
        /// Gets events by category (using Dictionary for O(1) lookup)
        /// </summary>
        public static List<Event> GetEventsByCategory(string category)
        {
            if (eventsByCategory.ContainsKey(category))
            {
                return new List<Event>(eventsByCategory[category]);
            }
            return new List<Event>();
        }

        /// <summary>
        /// Gets events within a date range (efficient with SortedDictionary)
        /// </summary>
        public static List<Event> GetEventsByDateRange(DateTime startDate, DateTime endDate)
        {
            List<Event> results = new List<Event>();

            foreach (var entry in eventsByDate)
            {
                if (entry.Key >= startDate.Date && entry.Key <= endDate.Date)
                {
                    results.AddRange(entry.Value);
                }
                else if (entry.Key > endDate.Date)
                {
                    break; // Sorted, so we can stop early
                }
            }

            return results;
        }

        /// <summary>
        /// Gets all unique categories (using HashSet)
        /// </summary>
        public static HashSet<string> GetAllCategories()
        {
            return new HashSet<string>(allCategories);
        }

        /// <summary>
        /// Gets all unique tags (using HashSet)
        /// </summary>
        public static HashSet<string> GetAllTags()
        {
            return new HashSet<string>(allTags);
        }

        /// <summary>
        /// Gets priority events (using Priority Queue via SortedSet)
        /// </summary>
        public static List<Event> GetPriorityEvents()
        {
            return new List<Event>(priorityEvents);
        }

        /// <summary>
        /// Adds search term to history (using Stack - LIFO)
        /// </summary>
        public static void AddSearchToHistory(string searchTerm)
        {
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                searchHistory.Push(searchTerm);
            }
        }

        /// <summary>
        /// Gets recent searches (using Stack)
        /// </summary>
        public static List<string> GetRecentSearches(int count = 5)
        {
            return searchHistory.Take(count).ToList();
        }

        /// <summary>
        /// Gets next notification from queue (using Queue - FIFO)
        /// </summary>
        public static Event GetNextNotification()
        {
            if (notificationQueue.Count > 0)
            {
                return notificationQueue.Dequeue();
            }
            return null;
        }

        /// <summary>
        /// Search events with recommendation algorithm
        /// Analyzes search patterns and uses multiple data structures
        /// </summary>
        public static List<Event> SearchEvents(string searchTerm, string category = null, DateTime? date = null)
        {
            // Add to search history
            AddSearchToHistory(searchTerm);

            List<Event> results = new List<Event>();

            // Start with all events
            IEnumerable<Event> searchPool = GetAllEvents();

            // Filter by category if specified
            if (!string.IsNullOrEmpty(category) && category != "All Categories")
            {
                searchPool = eventsByCategory.ContainsKey(category)
                    ? eventsByCategory[category]
                    : new List<Event>();
            }

            // Filter by date if specified
            if (date.HasValue)
            {
                DateTime dateKey = date.Value.Date;
                if (eventsByDate.ContainsKey(dateKey))
                {
                    searchPool = searchPool.Intersect(eventsByDate[dateKey]);
                }
            }

            // Search in title, description, and tags
            string lowerSearch = searchTerm?.ToLower() ?? "";
            foreach (Event evt in searchPool)
            {
                bool matches = string.IsNullOrEmpty(searchTerm) ||
                              evt.Title.ToLower().Contains(lowerSearch) ||
                              evt.Description.ToLower().Contains(lowerSearch) ||
                              evt.Tags.Any(t => t.ToLower().Contains(lowerSearch)) ||
                              evt.Location.ToLower().Contains(lowerSearch);

                if (matches)
                {
                    results.Add(evt);
                }
            }

            return results;
        }

        /// <summary>
        /// Recommendation algorithm based on user search patterns
        /// Uses search history and category analysis
        /// </summary>
        public static List<Event> GetRecommendedEvents(int count = 5)
        {
            List<Event> recommended = new List<Event>();

            // Analyze recent search history to determine user interests
            Dictionary<string, int> categoryInterest = new Dictionary<string, int>();
            Dictionary<string, int> tagInterest = new Dictionary<string, int>();

            foreach (string search in searchHistory)
            {
                string lowerSearch = search.ToLower();

                // Check which categories match search terms
                foreach (string cat in allCategories)
                {
                    if (cat.ToLower().Contains(lowerSearch))
                    {
                        categoryInterest[cat] = categoryInterest.ContainsKey(cat)
                            ? categoryInterest[cat] + 1
                            : 1;
                    }
                }

                // Check which tags match search terms
                foreach (string tag in allTags)
                {
                    if (tag.ToLower().Contains(lowerSearch))
                    {
                        tagInterest[tag] = tagInterest.ContainsKey(tag)
                            ? tagInterest[tag] + 1
                            : 1;
                    }
                }
                //(Microsoft, 2024 & Validation Techniques in C#, 2022)
            }

            // Get upcoming events
            List<Event> upcomingEvents = GetEventsByDateRange(DateTime.Today, DateTime.Today.AddMonths(3));

            // Score events based on user interests
            Dictionary<Event, int> eventScores = new Dictionary<Event, int>();

            foreach (Event evt in upcomingEvents)
            {
                int score = 0;

                // Score based on category interest
                if (categoryInterest.ContainsKey(evt.Category))
                {
                    score += categoryInterest[evt.Category] * 10;
                }

                // Score based on tag interest
                foreach (string tag in evt.Tags)
                {
                    if (tagInterest.ContainsKey(tag))
                    {
                        score += tagInterest[tag] * 5;
                    }
                }

                // Bonus for priority events
                score += (int)evt.Priority * 3;

                // Bonus for upcoming events
                int daysUntil = (evt.EventDate - DateTime.Now).Days;
                if (daysUntil >= 0 && daysUntil <= 7)
                {
                    score += 15; // Boost events within next week
                }

                eventScores[evt] = score;
            }

            // Sort by score and return top recommendations
            recommended = eventScores
                .OrderByDescending(kvp => kvp.Value)
                .Take(count)
                .Select(kvp => kvp.Key)
                .ToList();

            return recommended;
        }

        /// <summary>
        /// Gets event statistics for dashboard
        /// </summary>
        public static Dictionary<string, int> GetEventStatistics()
        {
            Dictionary<string, int> stats = new Dictionary<string, int>();

            stats["TotalEvents"] = GetAllEvents().Count;
            stats["TotalCategories"] = allCategories.Count;
            stats["UpcomingEvents"] = GetEventsByDateRange(DateTime.Today, DateTime.Today.AddMonths(1)).Count;
            stats["PriorityEvents"] = priorityEvents.Count;
            stats["SearchHistory"] = searchHistory.Count;

            return stats;
        }

        /// <summary>
        /// Load sample events for demonstration
        /// </summary>
        private static void LoadSampleEvents()
        {
            var sampleEvents = new[]
            {
                new Event
                {
                    Title = "Community Clean-Up Day",
                    Description = "Join us for a community-wide clean-up initiative. Help make our neighborhoods cleaner and greener!",
                    EventDate = DateTime.Today.AddDays(7),
                    Category = "🌳 Community Development",
                    Location = "Central Park, Pretoria",
                    Organizer = "Environmental Affairs Department",
                    Priority = EventPriority.High,
                    Tags = new HashSet<string> { "Environment", "Community", "Volunteer" }
                },
                new Event
                {
                    Title = "Water Conservation Workshop",
                    Description = "Learn practical tips and techniques for conserving water in your home and garden.",
                    EventDate = DateTime.Today.AddDays(14),
                    Category = "💧 Water & Sanitation",
                    Location = "Municipal Hall, Centurion",
                    Organizer = "Water Services Department",
                    Priority = EventPriority.High,
                    Tags = new HashSet<string> { "Water", "Education", "Conservation" }
                },
                new Event
                {
                    Title = "Road Maintenance Notice",
                    Description = "Scheduled road repairs on Main Street. Expect delays between 8 AM - 5 PM.",
                    EventDate = DateTime.Today.AddDays(3),
                    Category = "🚧 Roads & Infrastructure",
                    Location = "Main Street, Pretoria CBD",
                    Organizer = "Roads & Transport Department",
                    Priority = EventPriority.Urgent,
                    Tags = new HashSet<string> { "Roads", "Maintenance", "Traffic" }
                },
                new Event
                {
                    Title = "Municipal Budget Meeting",
                    Description = "Public meeting to discuss the upcoming municipal budget. All residents welcome to participate.",
                    EventDate = DateTime.Today.AddDays(21),
                    Category = "🏛️ Government & Administration",
                    Location = "Council Chambers, Pretoria",
                    Organizer = "Finance Department",
                    Priority = EventPriority.Normal,
                    Tags = new HashSet<string> { "Budget", "Meeting", "Participation" }
                },
                new Event
                {
                    Title = "Free Health Screening",
                    Description = "Free health screening and wellness checks for all community members. No appointment necessary.",
                    EventDate = DateTime.Today.AddDays(10),
                    Category = "🏥 Health & Safety",
                    Location = "Community Health Center",
                    Organizer = "Health Services Department",
                    Priority = EventPriority.High,
                    Tags = new HashSet<string> { "Health", "Free", "Community" }
                },
                new Event
                {
                    Title = "Youth Sports Tournament",
                    Description = "Annual youth sports tournament featuring soccer, netball, and athletics. Register your team today!",
                    EventDate = DateTime.Today.AddDays(30),
                    Category = "⚽ Sports & Recreation",
                    Location = "Municipal Sports Complex",
                    Organizer = "Recreation Department",
                    Priority = EventPriority.Normal,
                    Tags = new HashSet<string> { "Sports", "Youth", "Tournament" }
                },
                new Event
                {
                    Title = "Electricity Load Shedding Schedule Update",
                    Description = "Important update on load shedding schedules and affected areas. Please check your zone.",
                    EventDate = DateTime.Today.AddDays(1),
                    Category = "⚡ Electricity & Utilities",
                    Location = "City-wide",
                    Organizer = "Electricity Services",
                    Priority = EventPriority.Urgent,
                    Tags = new HashSet<string> { "Electricity", "Load Shedding", "Important" }
                },
                new Event
                {
                    Title = "Small Business Development Workshop",
                    Description = "Free workshop on starting and growing small businesses. Register online or at municipal offices.",
                    EventDate = DateTime.Today.AddDays(20),
                    Category = "💼 Economic Development",
                    Location = "Business Hub, Centurion",
                    Organizer = "Economic Development Unit",
                    Priority = EventPriority.Normal,
                    Tags = new HashSet<string> { "Business", "Workshop", "Development" }
                },
                new Event
                {
                    Title = "Heritage Day Celebration",
                    Description = "Celebrate South Africa's rich cultural heritage with food, music, and traditional performances.",
                    EventDate = DateTime.Today.AddDays(45),
                    Category = "🎭 Arts & Culture",
                    Location = "Freedom Park",
                    Organizer = "Arts & Culture Department",
                    Priority = EventPriority.Normal,
                    Tags = new HashSet<string> { "Heritage", "Culture", "Festival" }
                },
                new Event
                {
                    Title = "Public Safety Awareness Campaign",
                    Description = "Learn about crime prevention and community safety initiatives. Meet your local SAPS representatives.",
                    EventDate = DateTime.Today.AddDays(12),
                    Category = "🚨 Public Safety",
                    Location = "Community Center",
                    Organizer = "Public Safety Department",
                    Priority = EventPriority.High,
                    Tags = new HashSet<string> { "Safety", "Crime Prevention", "Community" }
                }
            };

            foreach (Event evt in sampleEvents)
            {
                AddEvent(evt);
            }
            //(Microsoft, 2024 & Validation Techniques in C#, 2022)
        }
    }

    /// <summary>
    /// Comparer for Priority Queue implementation
    /// Higher priority events come first, then sorted by date
    /// </summary>
    public class EventPriorityComparer : IComparer<Event>
    {
        public int Compare(Event x, Event y)
        {
            // First compare by priority (descending)
            int priorityComparison = y.Priority.CompareTo(x.Priority);
            if (priorityComparison != 0)
                return priorityComparison;

            // Then by date (ascending)
            int dateComparison = x.EventDate.CompareTo(y.EventDate);
            if (dateComparison != 0)
                return dateComparison;

            // Finally by ID to ensure uniqueness
            return x.EventId.CompareTo(y.EventId);
        }
        //(Microsoft, 2024 & Validation Techniques in C#, 2022)
    }
}
/*
Reference List
1. Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 07 September 2025]. 
2. Validation Techniques in C#. 2022. In: Smith, J. and Lee, A. eds. Programming best practices. Johannesburg: CodePress, Chapter 7: 112-130.
*/