﻿using MunicipalServicesApp.Models;
using System;
using System.Collections.Generic;

namespace MunicipalServicesApp.Services
{
    /// <summary>
    /// Binary Search Tree implementation for efficient ID-based lookups
    /// Time Complexity: O(log n) average for balanced tree
    /// Space Complexity: O(n)]
    /// 
    /// </summary>
    public class BinarySearchTree<TKey, TValue> where TKey : IComparable<TKey>
    {
        private class TreeNode
        {
            public TKey Key { get; set; }
            public TValue Value { get; set; }
            public TreeNode Left { get; set; }
            public TreeNode Right { get; set; }

            public TreeNode(TKey key, TValue value)
            {
                Key = key;
                Value = value;
                Left = null;
                Right = null;
            }
        }

        private TreeNode root;

        public BinarySearchTree()
        {
            root = null;
        }

        /// <summary>
        /// Inserts a key-value pair into the BST
        /// Time Complexity: O(log n) average, O(n) worst case
        /// </summary>
        public void Insert(TKey key, TValue value)
        {
            root = InsertRecursive(root, key, value);
        }

        private TreeNode InsertRecursive(TreeNode node, TKey key, TValue value)
        {
            if (node == null)
            {
                return new TreeNode(key, value);
            }

            int comparison = key.CompareTo(node.Key);

            if (comparison < 0)
            {
                node.Left = InsertRecursive(node.Left, key, value);
            }
            else if (comparison > 0)
            {
                node.Right = InsertRecursive(node.Right, key, value);
            }
            else
            {
                // Key already exists, update value
                node.Value = value;
            }

            return node;
        }

        /// <summary>
        /// Searches for a value by key
        /// Time Complexity: O(log n) average, O(n) worst case
        /// </summary>
        public TValue Search(TKey key)
        {
            TreeNode node = SearchRecursive(root, key);
            return node != null ? node.Value : default(TValue);
        }

        private TreeNode SearchRecursive(TreeNode node, TKey key)
        {
            if (node == null)
            {
                return null;
            }

            int comparison = key.CompareTo(node.Key);

            if (comparison == 0)
            {
                return node;
            }
            else if (comparison < 0)
            {
                return SearchRecursive(node.Left, key);
            }
            else
            {
                return SearchRecursive(node.Right, key);
            }
        }

        /// <summary>
        /// Performs in-order traversal of the tree
        /// Returns elements in sorted order by key
        /// </summary>
        public List<TValue> InOrderTraversal()
        {
            List<TValue> result = new List<TValue>();
            InOrderRecursive(root, result);
            return result;
        }

        private void InOrderRecursive(TreeNode node, List<TValue> result)
        {
            if (node != null)
            {
                InOrderRecursive(node.Left, result);
                result.Add(node.Value);
                InOrderRecursive(node.Right, result);
            }
        }
    }

    /// <summary>
    /// Min-Heap implementation for priority queue functionality
    /// Always maintains the minimum element at the root
    /// Time Complexity: O(log n) for insert and extract, O(1) for peek
    /// 
    /// Reference: Jamro, M. 2018. C# Data Structures and Algorithms. Chapter 5.
    /// </summary>
    public class MinHeap<T> where T : class
    {
        private List<ServiceRequest> heap;

        public MinHeap()
        {
            heap = new List<ServiceRequest>();
        }

        public int Count => heap.Count;

        /// <summary>
        /// Inserts an element and maintains heap property
        /// Time Complexity: O(log n)
        /// </summary>
        public void Insert(ServiceRequest request)
        {
            heap.Add(request);
            HeapifyUp(heap.Count - 1);
        }

        /// <summary>
        /// Returns the minimum element without removing it
        /// Time Complexity: O(1)
        /// </summary>
        public ServiceRequest Peek()
        {
            if (heap.Count == 0)
                return null;
            return heap[0];
        }

        /// <summary>
        /// Removes and returns the minimum element
        /// Time Complexity: O(log n)
        /// </summary>
        public ServiceRequest ExtractMin()
        {
            if (heap.Count == 0)
                return null;

            ServiceRequest min = heap[0];
            heap[0] = heap[heap.Count - 1];
            heap.RemoveAt(heap.Count - 1);

            if (heap.Count > 0)
            {
                HeapifyDown(0);
            }

            return min;
        }

        /// <summary>
        /// Maintains heap property by moving element up
        /// </summary>
        private void HeapifyUp(int index)
        {
            while (index > 0)
            {
                int parentIndex = (index - 1) / 2;

                // Compare by priority (higher priority number = more urgent = should be extracted first)
                // So we want higher priority at top, making this effectively a max-heap for priority
                if (heap[index].Priority <= heap[parentIndex].Priority)
                    break;

                // Swap
                ServiceRequest temp = heap[index];
                heap[index] = heap[parentIndex];
                heap[parentIndex] = temp;

                index = parentIndex;
            }
        }

        /// <summary>
        /// Maintains heap property by moving element down
        /// </summary>
        private void HeapifyDown(int index)
        {
            while (true)
            {
                int largest = index;
                int leftChild = 2 * index + 1;
                int rightChild = 2 * index + 2;

                // Find largest among node and its children (for max-heap behavior on priority)
                if (leftChild < heap.Count && heap[leftChild].Priority > heap[largest].Priority)
                {
                    largest = leftChild;
                }

                if (rightChild < heap.Count && heap[rightChild].Priority > heap[largest].Priority)
                {
                    largest = rightChild;
                }

                if (largest == index)
                    break;

                // Swap
                ServiceRequest temp = heap[index];
                heap[index] = heap[largest];
                heap[largest] = temp;

                index = largest;
            }
        }

        /// <summary>
        /// Returns all elements in the heap (not in sorted order)
        /// </summary>
        public List<ServiceRequest> GetAll()
        {
            return new List<ServiceRequest>(heap);
        }
    }

    /// <summary>
    /// Tree node for general tree structures
    /// Used for representing hierarchical relationships
    /// 
    /// Reference: Jamro, M. 2018. C# Data Structures and Algorithms. Chapter 5.
    /// </summary>
    public class TreeNode<T>
    {
        public T Data { get; set; }
        public TreeNode<T> Parent { get; set; }
        public List<TreeNode<T>> Children { get; set; }

        public TreeNode(T data)
        {
            Data = data;
            Children = new List<TreeNode<T>>();
            Parent = null;
        }

        /// <summary>
        /// Adds a child node to this node
        /// </summary>
        public TreeNode<T> AddChild(T data)
        {
            TreeNode<T> child = new TreeNode<T>(data);
            child.Parent = this;
            Children.Add(child);
            return child;
        }

        /// <summary>
        /// Gets the depth/level of this node in the tree
        /// </summary>
        public int GetDepth()
        {
            int depth = 0;
            TreeNode<T> current = this;
            while (current.Parent != null)
            {
                depth++;
                current = current.Parent;
            }
            return depth;
        }
    }

    /// <summary>
    /// Graph algorithms utility class
    /// Implements BFS, DFS, and MST concepts
    /// 
    /// Reference: Jamro, M. 2018. C# Data Structures and Algorithms. Chapter 6.
    /// </summary>
    public static class GraphAlgorithms
    {
        /// <summary>
        /// Breadth-First Search implementation
        /// Explores nodes level by level
        /// Time Complexity: O(V + E)
        /// </summary>
        public static List<int> BFS(Dictionary<int, List<int>> graph, int start)
        {
            List<int> result = new List<int>();
            HashSet<int> visited = new HashSet<int>();
            Queue<int> queue = new Queue<int>();

            queue.Enqueue(start);
            visited.Add(start);

            while (queue.Count > 0)
            {
                int current = queue.Dequeue();
                result.Add(current);

                if (graph.ContainsKey(current))
                {
                    foreach (int neighbor in graph[current])
                    {
                        if (!visited.Contains(neighbor))
                        {
                            visited.Add(neighbor);
                            queue.Enqueue(neighbor);
                        }
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Depth-First Search implementation
        /// Explores as far as possible along each branch
        /// Time Complexity: O(V + E)
        /// </summary>
        public static List<int> DFS(Dictionary<int, List<int>> graph, int start)
        {
            List<int> result = new List<int>();
            HashSet<int> visited = new HashSet<int>();

            DFSRecursive(graph, start, visited, result);

            return result;
        }

        private static void DFSRecursive(Dictionary<int, List<int>> graph, int current,
                                        HashSet<int> visited, List<int> result)
        {
            visited.Add(current);
            result.Add(current);

            if (graph.ContainsKey(current))
            {
                foreach (int neighbor in graph[current])
                {
                    if (!visited.Contains(neighbor))
                    {
                        DFSRecursive(graph, neighbor, visited, result);
                    }
                }
            }
        }

        /// <summary>
        /// Finds connected components in a graph
        /// Useful for identifying clusters of related requests
        /// </summary>
        public static List<List<int>> FindConnectedComponents(Dictionary<int, List<int>> graph)
        {
            List<List<int>> components = new List<List<int>>();
            HashSet<int> visited = new HashSet<int>();

            foreach (int vertex in graph.Keys)
            {
                if (!visited.Contains(vertex))
                {
                    List<int> component = new List<int>();
                    DFSComponent(graph, vertex, visited, component);
                    components.Add(component);
                }
            }

            return components;
        }

        private static void DFSComponent(Dictionary<int, List<int>> graph, int current,
                                        HashSet<int> visited, List<int> component)
        {
            visited.Add(current);
            component.Add(current);

            if (graph.ContainsKey(current))
            {
                foreach (int neighbor in graph[current])
                {
                    if (!visited.Contains(neighbor))
                    {
                        DFSComponent(graph, neighbor, visited, component);
                    }
                }
            }
        }
        //(Microsoft, 2024)
        //(Microsoft, 2024 & Validation Techniques in C#, 2022)
    }
}
/*
Reference List
1. Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 07 September 2025]. 
2. Validation Techniques in C#. 2022. In: Smith, J. and Lee, A. eds. Programming best practices. Johannesburg: CodePress, Chapter 7: 112-130.
*/
