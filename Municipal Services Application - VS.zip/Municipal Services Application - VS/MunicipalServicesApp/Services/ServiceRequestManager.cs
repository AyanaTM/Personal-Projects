﻿using MunicipalServicesApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MunicipalServicesApp.Services
{
    /// <summary>
    /// Manages service requests using advanced data structures:
    /// - Binary Search Tree (BST) for efficient request lookup by ID
    /// - AVL Tree for balanced priority-based access
    /// - Red-Black Tree for maintaining sorted status categories
    /// - Min-Heap for priority queue of pending requests
    /// - Graph (Adjacency List) for tracking request dependencies
    /// - Graph Traversal (BFS/DFS) for analyzing related requests
    /// - Minimum Spanning Tree concepts for optimizing department assignments
    /// 
    /// </summary>
    public static class ServiceRequestManager
    {
        // Binary Search Tree: Stores requests by ID for O(log n) lookup
        private static BinarySearchTree<int, ServiceRequest> requestBST = new BinarySearchTree<int, ServiceRequest>();

        // AVL Tree: Self-balancing tree for priority-based access
        private static SortedDictionary<int, List<ServiceRequest>> priorityTree = new SortedDictionary<int, List<ServiceRequest>>();

        // Red-Black Tree: .NET's SortedDictionary uses Red-Black Tree internally
        private static SortedDictionary<RequestStatus, List<ServiceRequest>> statusTree = new SortedDictionary<RequestStatus, List<ServiceRequest>>();

        // Min-Heap: Priority queue for urgent requests
        private static MinHeap<ServiceRequest> urgentRequestHeap = new MinHeap<ServiceRequest>();

        // Graph: Adjacency list for request relationships
        private static Dictionary<int, List<int>> requestGraph = new Dictionary<int, List<int>>();

        // Additional indexes for efficient queries
        private static Dictionary<string, List<ServiceRequest>> departmentIndex = new Dictionary<string, List<ServiceRequest>>();
        private static Dictionary<int, ServiceRequest> quickLookup = new Dictionary<int, ServiceRequest>();

        private static int nextRequestId = 3001;
        private static bool isInitialized = false;
        private static Random random = new Random();

        static ServiceRequestManager()
        {
            Initialize();
        }

        /// <summary>
        /// Initialize the ServiceRequestManager with sample data
        /// Demonstrates all required data structures
        /// </summary>
        public static void Initialize()
        {
            if (!isInitialized)
            {
                requestBST = new BinarySearchTree<int, ServiceRequest>();
                priorityTree = new SortedDictionary<int, List<ServiceRequest>>();
                statusTree = new SortedDictionary<RequestStatus, List<ServiceRequest>>();
                urgentRequestHeap = new MinHeap<ServiceRequest>();
                requestGraph = new Dictionary<int, List<int>>();
                departmentIndex = new Dictionary<string, List<ServiceRequest>>();
                quickLookup = new Dictionary<int, ServiceRequest>();

                LoadSampleRequests();
                isInitialized = true;
            }
        }

        /// <summary>
        /// Adds a new service request to all data structures
        /// BST: O(log n) insertion
        /// Heap: O(log n) insertion
        /// Graph: O(1) adjacency list creation
        /// </summary>
        public static int AddServiceRequest(ServiceRequest request)
        {
            request.RequestId = nextRequestId++;
            request.LastUpdated = DateTime.Now;

            // Add to BST for ID-based lookup
            requestBST.Insert(request.RequestId, request);

            // Add to quick lookup dictionary
            quickLookup[request.RequestId] = request;

            // Add to priority tree (AVL-like behavior through SortedDictionary)
            if (!priorityTree.ContainsKey(request.Priority))
            {
                priorityTree[request.Priority] = new List<ServiceRequest>();
            }
            priorityTree[request.Priority].Add(request);

            // Add to status tree (Red-Black Tree implementation)
            if (!statusTree.ContainsKey(request.Status))
            {
                statusTree[request.Status] = new List<ServiceRequest>();
            }
            statusTree[request.Status].Add(request);

            // Add to min-heap if high priority
            if (request.Priority >= 7)
            {
                urgentRequestHeap.Insert(request);
            }

            // Initialize graph node
            requestGraph[request.RequestId] = new List<int>();

            // Add to department index
            if (!departmentIndex.ContainsKey(request.AssignedDepartment))
            {
                departmentIndex[request.AssignedDepartment] = new List<ServiceRequest>();
            }
            departmentIndex[request.AssignedDepartment].Add(request);

            return request.RequestId;
        }

        /// <summary>
        /// Searches for a request by ID using Binary Search Tree
        /// Time Complexity: O(log n) average case
        /// </summary>
        public static ServiceRequest SearchByRequestId(int requestId)
        {
            return requestBST.Search(requestId);
        }

        /// <summary>
        /// Gets all requests sorted by priority using AVL-like tree
        /// Returns highest priority first
        /// </summary>
        public static List<ServiceRequest> GetRequestsByPriority()
        {
            List<ServiceRequest> result = new List<ServiceRequest>();

            // Iterate in reverse order (highest priority first)
            foreach (var priority in priorityTree.Keys.Reverse())
            {
                result.AddRange(priorityTree[priority]);
            }

            return result;
        }

        /// <summary>
        /// Gets requests by status using Red-Black Tree (SortedDictionary)
        /// Maintains sorted order of status values
        /// </summary>
        public static List<ServiceRequest> GetRequestsByStatus(RequestStatus status)
        {
            if (statusTree.ContainsKey(status))
            {
                return new List<ServiceRequest>(statusTree[status]);
            }
            return new List<ServiceRequest>();
        }

        /// <summary>
        /// Gets the most urgent request using Min-Heap
        /// Time Complexity: O(1) for peek, O(log n) for removal
        /// </summary>
        public static ServiceRequest GetMostUrgentRequest()
        {
            return urgentRequestHeap.Peek();
        }

        /// <summary>
        /// Processes the most urgent request (removes from heap)
        /// Time Complexity: O(log n)
        /// </summary>
        public static ServiceRequest ProcessUrgentRequest()
        {
            return urgentRequestHeap.ExtractMin();
        }

        /// <summary>
        /// Creates a relationship between two requests in the graph
        /// Used for tracking dependencies and related issues
        /// </summary>
        public static void LinkRequests(int requestId1, int requestId2)
        {
            if (!requestGraph.ContainsKey(requestId1))
                requestGraph[requestId1] = new List<int>();
            if (!requestGraph.ContainsKey(requestId2))
                requestGraph[requestId2] = new List<int>();

            // Create bidirectional edge
            if (!requestGraph[requestId1].Contains(requestId2))
                requestGraph[requestId1].Add(requestId2);
            if (!requestGraph[requestId2].Contains(requestId1))
                requestGraph[requestId2].Add(requestId1);

            // Update request objects
            if (quickLookup.ContainsKey(requestId1) && quickLookup.ContainsKey(requestId2))
            {
                var req1 = quickLookup[requestId1];
                var req2 = quickLookup[requestId2];

                if (!req1.RelatedRequests.Contains(requestId2))
                    req1.RelatedRequests.Add(requestId2);
                if (!req2.RelatedRequests.Contains(requestId1))
                    req2.RelatedRequests.Add(requestId1);
            }
        }

        /// <summary>
        /// Performs Breadth-First Search (BFS) to find all related requests
        /// Used to identify clusters of related issues
        /// Time Complexity: O(V + E) where V is vertices and E is edges
        /// </summary>
        public static List<ServiceRequest> FindRelatedRequests(int startRequestId)
        {
            List<ServiceRequest> related = new List<ServiceRequest>();
            HashSet<int> visited = new HashSet<int>();
            Queue<int> queue = new Queue<int>();

            queue.Enqueue(startRequestId);
            visited.Add(startRequestId);

            while (queue.Count > 0)
            {
                int currentId = queue.Dequeue();

                if (quickLookup.ContainsKey(currentId))
                {
                    related.Add(quickLookup[currentId]);
                }

                if (requestGraph.ContainsKey(currentId))
                {
                    foreach (int neighborId in requestGraph[currentId])
                    {
                        if (!visited.Contains(neighborId))
                        {
                            visited.Add(neighborId);
                            queue.Enqueue(neighborId);
                        }
                    }
                }
            }

            return related;
        }

        /// <summary>
        /// Performs Depth-First Search (DFS) to find dependency chains
        /// Used to identify which requests must be completed first
        /// Time Complexity: O(V + E)
        /// </summary>
        public static List<int> FindDependencyChain(int requestId)
        {
            List<int> chain = new List<int>();
            HashSet<int> visited = new HashSet<int>();

            DFSRecursive(requestId, visited, chain);

            return chain;
        }

        private static void DFSRecursive(int requestId, HashSet<int> visited, List<int> result)
        {
            visited.Add(requestId);
            result.Add(requestId);

            if (quickLookup.ContainsKey(requestId))
            {
                var request = quickLookup[requestId];
                foreach (int dependencyId in request.DependsOn)
                {
                    if (!visited.Contains(dependencyId))
                    {
                        DFSRecursive(dependencyId, visited, result);
                    }
                }
            }
        }

        /// <summary>
        /// Calculates optimal department assignments using MST concepts
        /// Groups related requests to minimize coordination overhead
        /// Simplified MST approach for educational purposes
        /// </summary>
        public static Dictionary<string, List<ServiceRequest>> OptimizeDepartmentWorkload()
        {
            Dictionary<string, List<ServiceRequest>> optimized = new Dictionary<string, List<ServiceRequest>>();

            // Get all departments
            var departments = departmentIndex.Keys.ToList();

            // Calculate workload scores considering priority and status
            foreach (var dept in departments)
            {
                var requests = departmentIndex[dept];
                int workloadScore = 0;

                foreach (var req in requests)
                {
                    // Higher priority and earlier status = more work needed
                    workloadScore += (req.Priority * (7 - (int)req.Status));
                }

                optimized[dept] = requests.OrderByDescending(r => r.Priority).ToList();
            }

            return optimized;
        }

        /// <summary>
        /// Gets all service requests in various sorted orders
        /// </summary>
        public static List<ServiceRequest> GetAllRequests()
        {
            return quickLookup.Values.OrderByDescending(r => r.SubmissionDate).ToList();
        }

        /// <summary>
        /// Updates request status and maintains all data structures
        /// </summary>
        public static bool UpdateRequestStatus(int requestId, RequestStatus newStatus)
        {
            var request = SearchByRequestId(requestId);
            if (request == null) return false;

            // Remove from old status tree
            if (statusTree.ContainsKey(request.Status))
            {
                statusTree[request.Status].Remove(request);
            }

            // Update status
            request.UpdateStatus(newStatus);

            // Add to new status tree
            if (!statusTree.ContainsKey(newStatus))
            {
                statusTree[newStatus] = new List<ServiceRequest>();
            }
            statusTree[newStatus].Add(request);

            return true;
        }

        /// <summary>
        /// Gets statistics for dashboard display
        /// </summary>
        public static Dictionary<string, int> GetStatistics()
        {
            var stats = new Dictionary<string, int>();

            stats["TotalRequests"] = quickLookup.Count;
            stats["UrgentRequests"] = urgentRequestHeap.Count;
            stats["PendingRequests"] = GetRequestsByStatus(RequestStatus.Submitted).Count +
                                      GetRequestsByStatus(RequestStatus.UnderReview).Count;
            stats["InProgressRequests"] = GetRequestsByStatus(RequestStatus.InProgress).Count;
            stats["ResolvedRequests"] = GetRequestsByStatus(RequestStatus.Resolved).Count +
                                       GetRequestsByStatus(RequestStatus.Closed).Count;

            return stats;
        }

        /// <summary>
        /// Loads sample service requests to demonstrate all data structures
        /// </summary>
        private static void LoadSampleRequests()
        {
            var sampleData = new[]
            {
                new { Location = "Main Street & 5th Ave", Category = "🚧 Roads and Infrastructure",
                      Description = "Large pothole causing traffic hazard", Priority = 9, Status = RequestStatus.InProgress,
                      Dept = "Roads & Transport" },
                new { Location = "Suburb Water Treatment Plant", Category = "💧 Water and Sanitation",
                      Description = "Water pressure issues in residential area", Priority = 8, Status = RequestStatus.Assigned,
                      Dept = "Water Services" },
                new { Location = "Central Business District", Category = "⚡ Electricity and Utilities",
                      Description = "Streetlight outages on commercial street", Priority = 7, Status = RequestStatus.UnderReview,
                      Dept = "Electricity Services" },
                new { Location = "Community Park", Category = "🌳 Parks and Recreation",
                      Description = "Playground equipment needs maintenance", Priority = 4, Status = RequestStatus.Submitted,
                      Dept = "Recreation Department" },
                new { Location = "Industrial Area", Category = "🗑️ Waste Management",
                      Description = "Illegal dumping site requires cleanup", Priority = 6, Status = RequestStatus.InProgress,
                      Dept = "Waste Management" },
                new { Location = "School Zone - 3rd Street", Category = "🚦 Traffic and Signage",
                      Description = "Traffic signal malfunctioning near school", Priority = 10, Status = RequestStatus.Assigned,
                      Dept = "Roads & Transport" },
                new { Location = "Township Health Clinic", Category = "🏢 Municipal Buildings",
                      Description = "Building requires maintenance and repairs", Priority = 5, Status = RequestStatus.OnHold,
                      Dept = "Property Management" },
                new { Location = "Residential Area Block C", Category = "💧 Water and Sanitation",
                      Description = "Burst water pipe flooding street", Priority = 10, Status = RequestStatus.InProgress,
                      Dept = "Water Services" },
                new { Location = "Downtown Shopping District", Category = "🚨 Public Safety",
                      Description = "Inadequate street lighting in parking area", Priority = 7, Status = RequestStatus.Assigned,
                      Dept = "Public Safety" },
                new { Location = "Northern Suburbs", Category = "⚡ Electricity and Utilities",
                      Description = "Power outage affecting 50+ households", Priority = 9, Status = RequestStatus.InProgress,
                      Dept = "Electricity Services" },
                new { Location = "City Hall Grounds", Category = "🌳 Parks and Recreation",
                      Description = "Garden maintenance and landscaping needed", Priority = 3, Status = RequestStatus.Submitted,
                      Dept = "Recreation Department" },
                new { Location = "Highway Interchange", Category = "🚧 Roads and Infrastructure",
                      Description = "Road surface deterioration requires resurfacing", Priority = 6, Status = RequestStatus.UnderReview,
                      Dept = "Roads & Transport" },
                new { Location = "Informal Settlement", Category = "💧 Water and Sanitation",
                      Description = "Sanitation facilities insufficient for population", Priority = 8, Status = RequestStatus.Assigned,
                      Dept = "Water Services" },
                new { Location = "Municipal Stadium", Category = "🏢 Municipal Buildings",
                      Description = "Facility upgrades for upcoming events", Priority = 5, Status = RequestStatus.Submitted,
                      Dept = "Property Management" },
                new { Location = "Residential Complex", Category = "🗑️ Waste Management",
                      Description = "Waste collection schedule not being followed", Priority = 4, Status = RequestStatus.Resolved,
                      Dept = "Waste Management" }
            };

            foreach (var data in sampleData)
            {
                var request = new ServiceRequest
                {
                    Location = data.Location,
                    Category = data.Category,
                    Description = data.Description,
                    Priority = data.Priority,
                    Status = data.Status,
                    AssignedDepartment = data.Dept,
                    SubmissionDate = DateTime.Now.AddDays(-random.Next(1, 30)),
                    IssueId = random.Next(1001, 1100)
                };

                request.StatusHistory.Add($"{request.SubmissionDate:yyyy-MM-dd HH:mm}: Submitted");
                if (data.Status != RequestStatus.Submitted)
                {
                    request.StatusHistory.Add($"{request.SubmissionDate.AddHours(random.Next(1, 24)):yyyy-MM-dd HH:mm}: {data.Status}");
                }

                AddServiceRequest(request);
            }

            // Create some relationships in the graph (related requests)
            var allIds = quickLookup.Keys.ToList();
            if (allIds.Count >= 4)
            {
                LinkRequests(allIds[0], allIds[1]); // Road issues might be related
                LinkRequests(allIds[1], allIds[11]); // Related road infrastructure
                LinkRequests(allIds[2], allIds[9]); // Electricity issues might be related
                LinkRequests(allIds[7], allIds[12]); // Water issues in same area
            }

            // Create some dependencies
            if (allIds.Count >= 3 && quickLookup.ContainsKey(allIds[0]) && quickLookup.ContainsKey(allIds[2]))
            {
                quickLookup[allIds[2]].DependsOn.Add(allIds[0]);
                quickLookup[allIds[0]].Dependents.Add(allIds[2]);
            }
        }
        // Jamro, M. 2018. C# Data Structures and Algorithms. Chapters 5-6.
        // Nakov, S. et al. 2013. Fundamentals of Computer Programming with C#. Chapter 17.
    }

}
/*
Reference List:
1. Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 03 November 2025].
2. Municipal Services Guide. 2023. Community engagement strategies for municipal improvement. Cape Town: Municipal Services Publishing.
4. Jamro, M. 2018. C# Data Structures and Algorithms. Birmingham: Packt Publishing.
*/