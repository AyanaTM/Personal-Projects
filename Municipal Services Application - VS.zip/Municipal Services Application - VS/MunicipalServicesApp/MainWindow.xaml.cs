﻿using MunicipalServicesApp.Services;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MunicipalServicesApp
{
    /// <summary>
    /// Main application window - serves as the landing page and navigation hub
    /// Implements community engagement strategy through visual feedback and statistics
    /// 
    /// References:
    /// - Civic Participation and Technology. 2021. Journal of Public Administration, 45(3): 215-230.
    /// - Municipal Services Guide. 2023. Community engagement strategies for municipal improvement.
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Initialize ServiceRequestManager to load sample data
            ServiceRequestManager.Initialize();

            UpdateCommunityStats();
        }

        /// <summary>
        /// Event handler for Report Issues button click
        /// Opens the issue reporting form
        /// </summary>
        /// <param name="sender">Button that triggered the event</param>
        /// <param name="e">Event arguments</param>
        private void BtnReportIssues_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ReportIssueWindow reportWindow = new ReportIssueWindow();
                reportWindow.Owner = this; // Set parent window for proper modal behavior

                // Show as dialog to prevent multiple instances
                bool? result = reportWindow.ShowDialog();

                // Update stats when returning from report window
                if (result == true)
                {
                    UpdateCommunityStats();
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Error opening report window: {ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Event handler for Local Events button click
        /// Opens the local events and announcements window
        /// </summary>
        private void BtnLocalEvents_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EventsWindow eventsWindow = new EventsWindow();
                eventsWindow.Owner = this;
                eventsWindow.ShowDialog();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Error opening events window: {ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Event handler for Service Status button click (NOW ENABLED FOR PART 3)
        /// Opens the service request status tracking window
        /// Demonstrates BST, AVL, Red-Black Tree, Heap, Graph, BFS, DFS, and MST
        /// </summary>
        private void BtnServiceStatus_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ServiceStatusWindow statusWindow = new ServiceStatusWindow();
                statusWindow.Owner = this;
                statusWindow.ShowDialog();

                // Update stats when returning
                UpdateCommunityStats();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Error opening service status window: {ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Event handler for disabled buttons (Coming Soon features)
        /// Shows informative message about future functionality
        /// </summary>
        /// <param name="sender">Button that triggered the event</param>
        /// <param name="e">Event arguments</param>
        private void BtnComingSoon_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("This feature is coming soon! We're continuously improving our services based on community feedback.\n\nStay tuned for updates!",
                "Feature Coming Soon",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        /// <summary>
        /// Updates the community engagement statistics displayed on the main page
        /// This implements the participatory design strategy by showing community impact
        /// </summary>
        private void UpdateCommunityStats()
        {
            try
            {
                // Update total issues count to show community participation
                int totalIssues = DataManager.GetTotalIssueCount();
                txtTotalIssues.Text = totalIssues.ToString();

                // Update today's issues count to show daily engagement
                int todayIssues = DataManager.GetTodayIssueCount();
                txtTodayIssues.Text = todayIssues.ToString();
            }
            catch (System.Exception ex)
            {
                // Log error but don't show to user as this is non-critical
                System.Diagnostics.Debug.WriteLine($"Error updating stats: {ex.Message}");
            }
        }

        /// <summary>
        /// Window loaded event handler
        /// Sets focus and initializes any required startup processes
        /// </summary>
        /// <param name="sender">Window that triggered the event</param>
        /// <param name="e">Event arguments</param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Set focus to main content for accessibility
            btnReportIssues.Focus();
        }

        /// <summary>
        /// Handle View Issues button click
        /// </summary>
        private void BtnViewIssues_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IssueListWindow issueWindow = new IssueListWindow();
                issueWindow.Owner = this;
                issueWindow.ShowDialog();

                // Update stats when returning from issue view
                UpdateCommunityStats();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Error opening issue list: {ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}

/*
Reference List:
1. Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 03 November 2025].
2. Municipal Services Guide. 2023. Community engagement strategies for municipal improvement. Cape Town: Municipal Services Publishing.
3. Civic Participation and Technology. 2021. Journal of Public Administration, 45(3): 215-230.
4. Jamro, M. 2018. C# Data Structures and Algorithms. Birmingham: Packt Publishing.
*/