﻿using Microsoft.Win32;
using MunicipalServicesApp.Models;
using MunicipalServicesApp.Services;
using MunicipalServicesApp.Utils;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace MunicipalServicesApp
{
    /// <summary>
    /// Report Issue Window - handles municipal service issue reporting
    /// Implements community-centric participatory design through interactive feedback
    /// </summary>

    public partial class ReportIssueWindow : Window
    {
        private List<string> attachedFiles;
        private readonly Random random;

        public ReportIssueWindow()
        {
            InitializeComponent();
            attachedFiles = new List<string>();
            random = new Random();
            InitializeEngagementFeatures();
        }

        /// <summary>
        /// Initialize community engagement features and motivational content
        /// </summary>
        private void InitializeEngagementFeatures()
        {
            // Set random community impact level for engagement
            int impactValue = random.Next(60, 95);
            progressCommunityImpact.Value = impactValue;

            if (impactValue >= 85)
                txtImpactLevel.Text = "Very High";
            else if (impactValue >= 70)
                txtImpactLevel.Text = "High";
            else
                txtImpactLevel.Text = "Medium";

            // Set dynamic community message
            string[] messages = {
                "Your voice makes our community stronger!",
                "Every report helps improve our neighborhood!",
                "Together we build a better municipality!",
                "Your civic participation matters!",
                "Community-driven change starts with you!"
            };

            txtCommunityMessage.Text = messages[random.Next(messages.Length)];
        }

        /// <summary>
        /// Handle file attachment button click
        /// </summary>
        private void BtnAttachFile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog
                {
                    Title = "Attach Supporting Documents",
                    Filter = "All Supported Files|*.jpg;*.jpeg;*.png;*.pdf;*.doc;*.docx;*.txt|" +
                            "Image Files|*.jpg;*.jpeg;*.png|" +
                            "Document Files|*.pdf;*.doc;*.docx;*.txt|" +
                            "All Files|*.*",
                    Multiselect = true
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    foreach (string filename in openFileDialog.FileNames)
                    {
                        if (ValidationHelper.IsValidFile(filename))
                        {
                            if (!attachedFiles.Contains(filename))
                            {
                                attachedFiles.Add(filename);
                                listAttachments.Items.Add(System.IO.Path.GetFileName(filename));
                                lblFileError.Visibility = Visibility.Collapsed;
                            }
                        }
                        else
                        {
                            lblFileError.Visibility = Visibility.Visible;
                            MessageBox.Show($"File '{System.IO.Path.GetFileName(filename)}' is invalid.\n\n" +
                                          "Please ensure files are:\n" +
                                          "• Supported format (JPG, PNG, PDF, DOC, DOCX, TXT)\n" +
                                          "• Under 10MB in size",
                                          "Invalid File",
                                          MessageBoxButton.OK,
                                          MessageBoxImage.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error attaching file: {ex.Message}",
                              "File Attachment Error",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Handle remove file button click
        /// </summary>
        private void BtnRemoveFile_Click(object sender, RoutedEventArgs e)
        {
            if (listAttachments.SelectedIndex >= 0)
            {
                int selectedIndex = listAttachments.SelectedIndex;
                attachedFiles.RemoveAt(selectedIndex);
                listAttachments.Items.RemoveAt(selectedIndex);
                btnRemoveFile.IsEnabled = false;
                lblFileError.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Handle file list selection change
        /// </summary>
        private void ListAttachments_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnRemoveFile.IsEnabled = listAttachments.SelectedIndex >= 0;
        }

        /// <summary>
        /// Handle category selection change for engagement feedback
        /// </summary>
        private void CmbCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lblCategoryError != null)
                lblCategoryError.Visibility = Visibility.Collapsed;

            // Update community message based on category for engagement
            if (cmbCategory.SelectedIndex > 0)
            {
                if (cmbCategory.SelectedItem is ComboBoxItem selectedItem)
                {
                    string category = selectedItem.Content.ToString();

                    if (category.Contains("Roads"))
                        txtCommunityMessage.Text = "Better roads connect our community!";
                    else if (category.Contains("Water"))
                        txtCommunityMessage.Text = "Clean water is a community right!";
                    else if (category.Contains("Safety"))
                        txtCommunityMessage.Text = "Your safety reports protect everyone!";
                    else
                        txtCommunityMessage.Text = "Every improvement starts with your voice!";
                }
            }
        }

        /// <summary>
        /// Handle description text change with character count
        /// </summary>
        private void TxtDescription_TextChanged(object sender, TextChangedEventArgs e)
        {
            int charCount = txtDescription.Text.Length;
            txtCharCount.Text = $"{charCount} / 1000 characters";

            // Color coding for character count
            if (charCount > 950)
                txtCharCount.Foreground = (System.Windows.Media.Brush)FindResource("ErrorRed");
            else if (charCount > 900)
                txtCharCount.Foreground = (System.Windows.Media.Brush)FindResource("WarningOrange");
            else
                txtCharCount.Foreground = (System.Windows.Media.Brush)FindResource("DarkGray");

            lblDescriptionError.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Handle form submission with comprehensive validation
        /// </summary>
        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<string> validationErrors = ValidateForm();

                if (validationErrors.Count > 0)
                {
                    ShowValidationErrors(validationErrors);
                    return;
                }

                // Create new issue object
                Issue newIssue = new Issue
                {
                    Location = txtLocation.Text.Trim(),
                    Category = GetSelectedCategory(),
                    Description = txtDescription.Text.Trim(),
                    AttachmentPaths = new List<string>(attachedFiles)
                };

                // Save issue using DataManager
                int issueId = DataManager.AddIssue(newIssue);

                // Show success message with community engagement
                MessageBox.Show($"🎉 Issue Report Submitted Successfully!\n\n" +
                              $"Reference Number: #{issueId}\n" +
                              $"Location: {newIssue.Location}\n" +
                              $"Category: {newIssue.Category}\n" +
                              $"Submitted: {DateTime.Now:yyyy-MM-dd HH:mm}\n\n" +
                              "Thank you for helping improve our community!\n" +
                              "Your civic participation makes a difference.",
                              "Report Submitted",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);

                // Set dialog result and close
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error submitting report: {ex.Message}\n\n" +
                              "Please try again or contact support if the problem persists.",
                              "Submission Error",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Validate all form inputs
        /// </summary>
        private List<string> ValidateForm()
        {
            List<string> errors = new List<string>();

            // Validate location
            if (!ValidationHelper.IsValidLocation(txtLocation.Text))
            {
                errors.Add("Location must be 3-200 characters with valid characters only");
                lblLocationError.Visibility = Visibility.Visible;
            }
            else
            {
                lblLocationError.Visibility = Visibility.Collapsed;
            }

            // Validate category
            if (cmbCategory.SelectedIndex <= 0)
            {
                errors.Add("Please select an issue category");
                lblCategoryError.Visibility = Visibility.Visible;
            }
            else
            {
                lblCategoryError.Visibility = Visibility.Collapsed;
            }

            // Validate description
            if (!ValidationHelper.IsValidDescription(txtDescription.Text))
            {
                errors.Add("Description must be 10-1000 characters");
                lblDescriptionError.Visibility = Visibility.Visible;
            }
            else
            {
                lblDescriptionError.Visibility = Visibility.Collapsed;
            }

            return errors;
        }

        /// <summary>
        /// Display validation errors to user
        /// </summary>
        private void ShowValidationErrors(List<string> errors)
        {
            listValidationErrors.ItemsSource = errors;
            borderValidationSummary.Visibility = Visibility.Visible;
        }

        /// <summary>
        /// Get selected category text from ComboBox
        /// </summary>
        private string GetSelectedCategory()
        {
            if (cmbCategory.SelectedItem is ComboBoxItem selectedItem)
            {
                return selectedItem.Content.ToString();
            }
            return "Other";
        }

        /// <summary>
        /// Handle clear form button
        /// </summary>
        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "Are you sure you want to clear all form data?\n\nThis action cannot be undone.",
                "Clear Form",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                ClearForm();
            }
        }

        /// <summary>
        /// Clear all form fields and reset validation
        /// </summary>
        private void ClearForm()
        {
            txtLocation.Clear();
            cmbCategory.SelectedIndex = 0;
            txtDescription.Clear();
            attachedFiles.Clear();
            listAttachments.Items.Clear();

            // Hide all error messages
            lblLocationError.Visibility = Visibility.Collapsed;
            lblCategoryError.Visibility = Visibility.Collapsed;
            lblDescriptionError.Visibility = Visibility.Collapsed;
            lblFileError.Visibility = Visibility.Collapsed;
            borderValidationSummary.Visibility = Visibility.Collapsed;

            btnRemoveFile.IsEnabled = false;

            // Reset engagement features
            InitializeEngagementFeatures();
        }

        /// <summary>
        /// Handle back button click
        /// </summary>
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            if (HasFormData())
            {
                MessageBoxResult result = MessageBox.Show(
                    "You have unsaved changes. Are you sure you want to go back?\n\nAll data will be lost.",
                    "Unsaved Changes",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.No)
                    return;
            }

            DialogResult = false;
            Close();
        }

        /// <summary>
        /// Check if form has any data entered
        /// </summary>
        private bool HasFormData()
        {
            return !string.IsNullOrWhiteSpace(txtLocation.Text) ||
                   cmbCategory.SelectedIndex > 0 ||
                   !string.IsNullOrWhiteSpace(txtDescription.Text) ||
                   attachedFiles.Count > 0;
        }

        /// <summary>
        /// Handle window closing event
        /// </summary>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (DialogResult != true && HasFormData())
            {
                MessageBoxResult result = MessageBox.Show(
                    "You have unsaved changes. Are you sure you want to close?\n\nAll data will be lost.",
                    "Unsaved Changes",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.No)
                {
                    e.Cancel = true;
                }
                //(Microsoft, 2024 & Validation Techniques in C#, 2022)
            }
        }
        //(Civic Participation and Technology, 2021 & Municipal Services Guide, 2023)
    }
}
/*
Reference List
1. Microsoft. 2024. OpenFileDialog class. [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/api/microsoft.win32.openfiledialog [Accessed 07 September 2025].
2. Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 07 September 2025].
3. Municipal Services Guide. 2023. Community engagement strategies for municipal improvement. Cape Town: Municipal Services Publishing.
4. Validation Techniques in C#. 2022. In: Smith, J. and Lee, A. eds. Programming best practices. Johannesburg: CodePress, Chapter 7: 112-130.
5. Civic Participation and Technology. 2021. Journal of Public Administration, 45(3): 215-230.
*/
