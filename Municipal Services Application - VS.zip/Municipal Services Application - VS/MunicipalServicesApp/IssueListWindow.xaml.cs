﻿using MunicipalServicesApp.Models;
using MunicipalServicesApp.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MunicipalServicesApp
{
    /// <summary>
    /// Window for displaying all submitted community issues
    /// Demonstrates participatory design by showing community engagement
    /// </summary>
    public partial class IssueListWindow : Window
    {
        public IssueListWindow()
        {
            InitializeComponent();
            LoadIssues();
        }

        /// <summary>
        /// Load and display all issues
        /// </summary>
        private void LoadIssues()
        {
            try
            {
                List<Issue> issues = DataManager.GetAllIssues();
                panelIssues.Children.Clear();

                txtIssueCount.Text = $"Total Community Reports: {issues.Count}";

                if (issues.Count == 0)
                {
                    ShowNoIssuesMessage();
                }
                else
                {
                    foreach (Issue issue in issues)
                    {
                        CreateIssueCard(issue);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading issues: {ex.Message}",
                              "Load Error",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Show message when no issues are found
        /// </summary>
        private void ShowNoIssuesMessage()
        {
            Border messageCard = new Border
            {
                Background = (Brush)FindResource("White"),
                BorderBrush = (Brush)FindResource("DarkGray"),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(30),
                Margin = new Thickness(0, 20, 0, 0)
            };

            StackPanel messagePanel = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center
            };

            TextBlock titleBlock = new TextBlock
            {
                Text = "📋 No Issues Reported Yet",
                FontSize = 18,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("PrimaryBlue"),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10)
            };

            TextBlock descBlock = new TextBlock
            {
                Text = "Be the first to report a community issue and help improve our municipality!",
                FontSize = 14,
                Foreground = (Brush)FindResource("DarkGray"),
                TextAlignment = TextAlignment.Center,
                TextWrapping = TextWrapping.Wrap
            };

            messagePanel.Children.Add(titleBlock);
            messagePanel.Children.Add(descBlock);
            messageCard.Child = messagePanel;
            panelIssues.Children.Add(messageCard);
        }

        /// <summary>
        /// Create visual card for each issue
        /// </summary>
        private void CreateIssueCard(Issue issue)
        {
            Border card = new Border
            {
                Background = (Brush)FindResource("White"),
                BorderBrush = GetCategoryColor(issue.Category),
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(20),
                Margin = new Thickness(0, 0, 0, 15)
            };

            StackPanel cardContent = new StackPanel();

            // Header with ID and Date
            StackPanel header = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 10)
            };

            TextBlock idBlock = new TextBlock
            {
                Text = $"Report #{issue.IssueId}",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = (Brush)FindResource("PrimaryBlue")
            };

            TextBlock dateBlock = new TextBlock
            {
                Text = issue.SubmissionDate.ToString("yyyy-MM-dd HH:mm"),
                FontSize = 12,
                Foreground = (Brush)FindResource("DarkGray"),
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(20, 0, 0, 0)
            };

            header.Children.Add(idBlock);
            header.Children.Add(dateBlock);

            // Category and Status
            StackPanel infoRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 10)
            };

            Border categoryBadge = new Border
            {
                Background = GetCategoryColor(issue.Category),
                CornerRadius = new CornerRadius(12),
                Padding = new Thickness(10, 5, 10, 5),
                Margin = new Thickness(0, 0, 10, 0)
            };

            TextBlock categoryText = new TextBlock
            {
                Text = issue.Category,
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("White")
            };

            categoryBadge.Child = categoryText;

            Border statusBadge = new Border
            {
                Background = GetStatusColor(issue.Status),
                CornerRadius = new CornerRadius(12),
                Padding = new Thickness(10, 5, 10, 5)
            };

            TextBlock statusText = new TextBlock
            {
                Text = issue.Status,
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("White")
            };

            statusBadge.Child = statusText;

            infoRow.Children.Add(categoryBadge);
            infoRow.Children.Add(statusBadge);

            // Location
            TextBlock locationBlock = new TextBlock
            {
                Text = $"📍 {issue.Location}",
                FontSize = 14,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("PrimaryBlue"),
                Margin = new Thickness(0, 0, 0, 8)
            };

            // Description
            TextBlock descBlock = new TextBlock
            {
                Text = issue.Description,
                FontSize = 13,
                Foreground = (Brush)FindResource("DarkGray"),
                TextWrapping = TextWrapping.Wrap,
                MaxHeight = 60
            };

            // Attachments info
            if (issue.AttachmentPaths != null && issue.AttachmentPaths.Count > 0)
            {
                TextBlock attachmentBlock = new TextBlock
                {
                    Text = $"📎 {issue.AttachmentPaths.Count} attachment(s)",
                    FontSize = 12,
                    Foreground = (Brush)FindResource("AccentGreen"),
                    Margin = new Thickness(0, 10, 0, 0)
                };
                cardContent.Children.Add(attachmentBlock);
            }

            cardContent.Children.Add(header);
            cardContent.Children.Add(infoRow);
            cardContent.Children.Add(locationBlock);
            cardContent.Children.Add(descBlock);

            card.Child = cardContent;
            panelIssues.Children.Add(card);
        }

        /// <summary>
        /// Get color based on issue category
        /// </summary>
        private Brush GetCategoryColor(string category)
        {
            if (category.Contains("Roads") || category.Contains("Infrastructure"))
                return (Brush)FindResource("WarningOrange");
            else if (category.Contains("Water") || category.Contains("Sanitation"))
                return (Brush)FindResource("SecondaryBlue");
            else if (category.Contains("Safety") || category.Contains("Emergency"))
                return (Brush)FindResource("ErrorRed");
            else if (category.Contains("Parks") || category.Contains("Environment"))
                return (Brush)FindResource("AccentGreen");
            else
                return (Brush)FindResource("DarkGray");
        }

        /// <summary>
        /// Get color based on issue status
        /// </summary>
        private Brush GetStatusColor(string status)
        {
            switch (status.ToLower())
            {
                case "pending":
                    return (Brush)FindResource("WarningOrange");
                case "in progress":
                    return (Brush)FindResource("SecondaryBlue");
                case "resolved":
                    return (Brush)FindResource("AccentGreen");
                default:
                    return (Brush)FindResource("DarkGray");
            }
        }
        //(Civic Participation and Technology, 2021 & Municipal Services Guide, 2023)

        /// <summary>
        /// Handle back button click
        /// </summary>
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Handle refresh button click
        /// </summary>
        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadIssues();
        }
    }
    //(Microsoft, 2024 & Validation Techniques in C#, 2022)
}
/*
Reference List
1. Microsoft. 2024. OpenFileDialog class. [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/api/microsoft.win32.openfiledialog [Accessed 07 September 2025].
2. Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 07 September 2025].
3. Municipal Services Guide. 2023. Community engagement strategies for municipal improvement. Cape Town: Municipal Services Publishing.
4. Validation Techniques in C#. 2022. In: Smith, J. and Lee, A. eds. Programming best practices. Johannesburg: CodePress, Chapter 7: 112-130.
5. Civic Participation and Technology. 2021. Journal of Public Administration, 45(3): 215-230.
*/
