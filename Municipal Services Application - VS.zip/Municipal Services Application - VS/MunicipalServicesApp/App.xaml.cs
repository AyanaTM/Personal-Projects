﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace MunicipalServicesApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        /// <summary>
        /// Application startup event handler
        /// </summary>
        /// <param name="e">Startup event arguments</param>
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Set up global exception handling
            this.DispatcherUnhandledException += App_DispatcherUnhandledException;
        }

        /// <summary>
        /// Global exception handler for unhandled exceptions
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="e">Exception event arguments</param>
        private void App_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            MessageBox.Show($"An unexpected error occurred: {e.Exception.Message}",
                           "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            e.Handled = true;
        }
        //(Microsoft, 2024 & Validation Techniques in C#, 2022)
    }

}
/*
Reference List
1. Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 07 September 2025]. 
2. Validation Techniques in C#. 2022. In: Smith, J. and Lee, A. eds. Programming best practices. Johannesburg: CodePress, Chapter 7: 112-130.
*/
