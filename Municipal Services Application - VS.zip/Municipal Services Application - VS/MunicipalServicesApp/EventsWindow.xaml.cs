﻿using MunicipalServicesApp.Models;
using MunicipalServicesApp.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MunicipalServicesApp
{
    /// <summary>
    /// Interaction logic for EventsWindow.xaml
    /// </summary>

    public partial class EventsWindow : Window
    {
        private List<Event> currentEvents;
        private System.Windows.Threading.DispatcherTimer searchDebounceTimer;

        public EventsWindow()
        {
            InitializeComponent();
            InitializeSearchDebounce();
            LoadInitialData();
        }

        /// <summary>
        /// Initialize debounce timer for search to avoid excessive filtering
        /// </summary>
        private void InitializeSearchDebounce()
        {
            searchDebounceTimer = new System.Windows.Threading.DispatcherTimer();
            searchDebounceTimer.Interval = TimeSpan.FromMilliseconds(300);
            searchDebounceTimer.Tick += SearchDebounceTimer_Tick;
        }

        /// <summary>
        /// Load initial data and populate UI
        /// </summary>
        private void LoadInitialData()
        {
            try
            {
                LoadCategories();
                LoadAllEvents();
                LoadPriorityEvents();
                LoadRecommendedEvents();
                LoadRecentSearches();
                LoadStatistics();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading events: {ex.Message}",
                    "Load Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Load categories into dropdown (using HashSet)
        /// </summary>
        private void LoadCategories()
        {
            cmbCategory.Items.Clear();
            cmbCategory.Items.Add("All Categories");

            // HashSet ensures unique categories
            HashSet<string> categories = Services.EventManager.GetAllCategories();
            foreach (string category in categories.OrderBy(c => c))
            {
                cmbCategory.Items.Add(category);
            }

            cmbCategory.SelectedIndex = 0;
        }

        /// <summary>
        /// Load all events (using SortedDictionary internally)
        /// </summary>
        private void LoadAllEvents()
        {
            currentEvents = Services.EventManager.GetAllEvents();
            DisplayEvents(currentEvents);
            UpdateEventCount();
        }

        /// <summary>
        /// Display events in the main panel
        /// </summary>
        private void DisplayEvents(List<Event> events)
        {
            panelEvents.Children.Clear();

            if (events == null || events.Count == 0)
            {
                ShowNoEventsMessage();
                return;
            }

            foreach (Event evt in events)
            {
                CreateEventCard(evt, panelEvents);
            }
        }

        /// <summary>
        /// Create visual card for an event
        /// </summary>
        private void CreateEventCard(Event evt, StackPanel container)
        {
            Border card = new Border
            {
                Background = (Brush)FindResource("White"),
                BorderBrush = GetPriorityColor(evt.Priority),
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(20),
                Margin = new Thickness(0, 0, 0, 15)
            };

            StackPanel cardContent = new StackPanel();

            // Header with title and date
            Grid headerGrid = new Grid();
            headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            TextBlock titleBlock = new TextBlock
            {
                Text = evt.Title,
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                Foreground = (Brush)FindResource("PrimaryBlue"),
                TextWrapping = TextWrapping.Wrap
            };
            Grid.SetColumn(titleBlock, 0);

            StackPanel datePanel = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Right
            };
            TextBlock dateBlock = new TextBlock
            {
                Text = evt.EventDate.ToString("ddd, dd MMM yyyy"),
                FontSize = 14,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("SecondaryBlue")
            };
            TextBlock timeBlock = new TextBlock
            {
                Text = evt.EventDate.ToString("HH:mm"),
                FontSize = 12,
                Foreground = (Brush)FindResource("DarkGray"),
                HorizontalAlignment = HorizontalAlignment.Right
            };
            datePanel.Children.Add(dateBlock);
            datePanel.Children.Add(timeBlock);
            Grid.SetColumn(datePanel, 1);

            headerGrid.Children.Add(titleBlock);
            headerGrid.Children.Add(datePanel);

            // Category and Priority badges
            StackPanel badgePanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 10, 0, 10)
            };

            Border categoryBadge = new Border
            {
                Background = GetCategoryColor(evt.Category),
                CornerRadius = new CornerRadius(12),
                Padding = new Thickness(10, 5, 10, 5),
                Margin = new Thickness(0, 0, 10, 0)
            };
            categoryBadge.Child = new TextBlock
            {
                Text = evt.Category,
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("White")
            };

            if (evt.Priority >= EventPriority.High)
            {
                Border priorityBadge = new Border
                {
                    Background = GetPriorityColor(evt.Priority),
                    CornerRadius = new CornerRadius(12),
                    Padding = new Thickness(10, 5, 10, 5)
                };
                priorityBadge.Child = new TextBlock
                {
                    Text = evt.Priority == EventPriority.Urgent ? "⚠️ URGENT" : "⚡ HIGH PRIORITY",
                    FontSize = 12,
                    FontWeight = FontWeights.Bold,
                    Foreground = (Brush)FindResource("White")
                };
                badgePanel.Children.Add(priorityBadge);
            }

            badgePanel.Children.Add(categoryBadge);

            // Location
            StackPanel locationPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 10)
            };
            locationPanel.Children.Add(new TextBlock
            {
                Text = "📍 ",
                FontSize = 14
            });
            locationPanel.Children.Add(new TextBlock
            {
                Text = evt.Location,
                FontSize = 14,
                Foreground = (Brush)FindResource("DarkGray")
            });

            // Organizer
            StackPanel organizerPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 10)
            };
            organizerPanel.Children.Add(new TextBlock
            {
                Text = "🏛️ ",
                FontSize = 14
            });
            organizerPanel.Children.Add(new TextBlock
            {
                Text = evt.Organizer,
                FontSize = 13,
                FontStyle = FontStyles.Italic,
                Foreground = (Brush)FindResource("DarkGray")
            });

            // Description
            TextBlock descBlock = new TextBlock
            {
                Text = evt.Description,
                FontSize = 14,
                Foreground = (Brush)FindResource("DarkGray"),
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 10)
            };

            // Tags
            if (evt.Tags.Count > 0)
            {
                StackPanel tagPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(0, 5, 0, 0)
                };
                tagPanel.Children.Add(new TextBlock
                {
                    Text = "🏷️ ",
                    FontSize = 12
                });

                foreach (string tag in evt.Tags)
                {
                    Border tagBorder = new Border
                    {
                        Background = (Brush)FindResource("LightGray"),
                        CornerRadius = new CornerRadius(8),
                        Padding = new Thickness(8, 3, 8, 3),
                        Margin = new Thickness(0, 0, 5, 0)
                    };
                    tagBorder.Child = new TextBlock
                    {
                        Text = tag,
                        FontSize = 11,
                        Foreground = (Brush)FindResource("DarkGray")
                    };
                    tagPanel.Children.Add(tagBorder);
                }

                cardContent.Children.Add(tagPanel);
            }

            cardContent.Children.Add(headerGrid);
            cardContent.Children.Add(badgePanel);
            cardContent.Children.Add(locationPanel);
            cardContent.Children.Add(organizerPanel);
            cardContent.Children.Add(descBlock);

            card.Child = cardContent;
            container.Children.Add(card);
        }

        /// <summary>
        /// Load priority events (using Priority Queue via SortedSet)
        /// </summary>
        private void LoadPriorityEvents()
        {
            panelPriorityEvents.Children.Clear();

            List<Event> priorityEvents = Services.EventManager.GetPriorityEvents();

            if (priorityEvents.Count == 0)
            {
                TextBlock noEvents = new TextBlock
                {
                    Text = "No urgent announcements",
                    FontSize = 12,
                    Foreground = (Brush)FindResource("DarkGray"),
                    FontStyle = FontStyles.Italic
                };
                panelPriorityEvents.Children.Add(noEvents);
                return;
            }

            foreach (Event evt in priorityEvents.Take(5))
            {
                CreateCompactEventCard(evt, panelPriorityEvents);
            }
        }

        /// <summary>
        /// Load recommended events (using recommendation algorithm)
        /// </summary>
        private void LoadRecommendedEvents()
        {
            panelRecommendedEvents.Children.Clear();

            List<Event> recommendations = Services.EventManager.GetRecommendedEvents(5);

            if (recommendations.Count == 0)
            {
                TextBlock noRecs = new TextBlock
                {
                    Text = "Start searching to get personalized recommendations!",
                    FontSize = 12,
                    Foreground = (Brush)FindResource("DarkGray"),
                    FontStyle = FontStyles.Italic,
                    TextWrapping = TextWrapping.Wrap
                };
                panelRecommendedEvents.Children.Add(noRecs);
                return;
            }

            foreach (Event evt in recommendations)
            {
                CreateCompactEventCard(evt, panelRecommendedEvents);
            }
        }

        /// <summary>
        /// Create compact event card for sidebar
        /// </summary>
        private void CreateCompactEventCard(Event evt, StackPanel container)
        {
            Border card = new Border
            {
                Background = (Brush)FindResource("LightGray"),
                BorderBrush = (Brush)FindResource("DarkGray"),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(10),
                Margin = new Thickness(0, 0, 0, 10)
            };

            StackPanel content = new StackPanel();

            TextBlock titleBlock = new TextBlock
            {
                Text = evt.Title,
                FontSize = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("PrimaryBlue"),
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 5)
            };

            TextBlock dateBlock = new TextBlock
            {
                Text = $"📅 {evt.EventDate:dd MMM yyyy}",
                FontSize = 11,
                Foreground = (Brush)FindResource("DarkGray")
            };

            content.Children.Add(titleBlock);
            content.Children.Add(dateBlock);

            card.Child = content;
            container.Children.Add(card);
        }

        /// <summary>
        /// Load recent searches (using Stack - LIFO)
        /// </summary>
        private void LoadRecentSearches()
        {
            List<string> recentSearches = Services.EventManager.GetRecentSearches(5);
            listRecentSearches.ItemsSource = recentSearches;
        }

        /// <summary>
        /// Load statistics
        /// </summary>
        private void LoadStatistics()
        {
            panelStatistics.Children.Clear();

            Dictionary<string, int> stats = Services.EventManager.GetEventStatistics();

            AddStatItem("Total Events", stats["TotalEvents"].ToString());
            AddStatItem("Categories", stats["TotalCategories"].ToString());
            AddStatItem("Upcoming (30 days)", stats["UpcomingEvents"].ToString());
            AddStatItem("Priority Events", stats["PriorityEvents"].ToString());
        }

        private void AddStatItem(string label, string value)
        {
            Grid statGrid = new Grid { Margin = new Thickness(0, 0, 0, 8) };
            statGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            statGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            TextBlock labelBlock = new TextBlock
            {
                Text = label,
                FontSize = 12,
                Foreground = (Brush)FindResource("DarkGray")
            };
            Grid.SetColumn(labelBlock, 0);

            TextBlock valueBlock = new TextBlock
            {
                Text = value,
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = (Brush)FindResource("PrimaryBlue")
            };
            Grid.SetColumn(valueBlock, 1);

            statGrid.Children.Add(labelBlock);
            statGrid.Children.Add(valueBlock);
            panelStatistics.Children.Add(statGrid);
        }

        /// <summary>
        /// Handle search text change with debouncing
        /// </summary>
        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            searchDebounceTimer.Stop();
            searchDebounceTimer.Start();
        }

        private void SearchDebounceTimer_Tick(object sender, EventArgs e)
        {
            searchDebounceTimer.Stop();
            PerformSearch();
        }

        /// <summary>
        /// Perform search with filters
        /// </summary>
        private void PerformSearch()
        {
            string searchTerm = txtSearch.Text;
            string category = cmbCategory.SelectedItem?.ToString();
            DateTime? selectedDate = dpDate.SelectedDate;

            // Use EventManager's search functionality
            List<Event> results =  Services.EventManager.SearchEvents(searchTerm, category, selectedDate);

            DisplayEvents(results);
            UpdateEventCount(results.Count);

            // Update recommendations based on new search
            LoadRecommendedEvents();
            LoadRecentSearches();
        }

        /// <summary>
        /// Handle category selection change
        /// </summary>
        private void CmbCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbCategory.SelectedIndex >= 0)
            {
                PerformSearch();
            }
        }

        /// <summary>
        /// Handle date picker change
        /// </summary>
        private void DpDate_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            PerformSearch();
        }

        /// <summary>
        /// Clear all filters
        /// </summary>
        private void BtnClearFilters_Click(object sender, RoutedEventArgs e)
        {
            txtSearch.Clear();
            cmbCategory.SelectedIndex = 0;
            dpDate.SelectedDate = null;
            LoadAllEvents();
        }

        /// <summary>
        /// Handle recent search button click
        /// </summary>
        private void BtnRecentSearch_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Content is string searchTerm)
            {
                txtSearch.Text = searchTerm;
                PerformSearch();
            }
        }

        /// <summary>
        /// Update event count display
        /// </summary>
        private void UpdateEventCount(int? count = null)
        {
            int displayCount = count ?? currentEvents?.Count ?? 0;
            int totalCount = Services.EventManager.GetAllEvents().Count;

            if (count.HasValue && count.Value < totalCount)
            {
                txtEventCount.Text = $"Showing {displayCount} of {totalCount} events";
            }
            else
            {
                txtEventCount.Text = $"Total Events: {totalCount}";
            }
        }

        /// <summary>
        /// Show message when no events found
        /// </summary>
        private void ShowNoEventsMessage()
        {
            Border messageCard = new Border
            {
                Background = (Brush)FindResource("White"),
                BorderBrush = (Brush)FindResource("DarkGray"),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(40),
                Margin = new Thickness(0, 20, 0, 0)
            };

            StackPanel messagePanel = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center
            };

            messagePanel.Children.Add(new TextBlock
            {
                Text = "📅 No Events Found",
                FontSize = 20,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("PrimaryBlue"),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10)
            });

            messagePanel.Children.Add(new TextBlock
            {
                Text = "Try adjusting your search criteria or clearing filters.",
                FontSize = 14,
                Foreground = (Brush)FindResource("DarkGray"),
                TextAlignment = TextAlignment.Center,
                TextWrapping = TextWrapping.Wrap
            });

            messageCard.Child = messagePanel;
            panelEvents.Children.Add(messageCard);
        }

        /// <summary>
        /// Get color based on category
        /// </summary>
        private Brush GetCategoryColor(string category)
        {
            if (category.Contains("Community")) return (Brush)FindResource("AccentGreen");
            if (category.Contains("Water")) return (Brush)FindResource("SecondaryBlue");
            if (category.Contains("Roads")) return (Brush)FindResource("WarningOrange");
            if (category.Contains("Safety")) return (Brush)FindResource("ErrorRed");
            if (category.Contains("Health")) return (Brush)FindResource("AccentGreen");
            return (Brush)FindResource("PrimaryBlue");
        }

        /// <summary>
        /// Get color based on priority
        /// </summary>
        private Brush GetPriorityColor(EventPriority priority)
        {
            switch (priority)
            {
                case EventPriority.Urgent:
                    return (Brush)FindResource("ErrorRed");
                case EventPriority.High:
                    return (Brush)FindResource("WarningOrange");
                case EventPriority.Normal:
                    return (Brush)FindResource("SecondaryBlue");
                default:
                    return (Brush)FindResource("DarkGray");
            }
        }

        /// <summary>
        /// Handle back button
        /// </summary>
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Handle refresh button
        /// </summary>
        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadInitialData();
            MessageBox.Show("Events refreshed successfully!", "Refresh Complete",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}