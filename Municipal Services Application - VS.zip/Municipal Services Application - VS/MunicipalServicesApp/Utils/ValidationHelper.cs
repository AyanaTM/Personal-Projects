﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MunicipalServicesApp.Utils
{
    /// <summary>
    /// Provides validation methods for user input and file operations
    /// </summary>
    public static class ValidationHelper
    {
        private const long MaxFileSizeBytes = 10 * 1024 * 1024; // 10MB limit
        private static readonly string[] AllowedFileExtensions = { ".jpg", ".jpeg", ".png", ".pdf", ".doc", ".docx", ".txt" };

        /// <summary>
        /// Validates location input - must not be empty and contain valid characters
        /// </summary>
        /// <param name="location">Location string to validate</param>
        /// <returns>True if valid, false otherwise</returns>
        public static bool IsValidLocation(string location)
        {
            if (string.IsNullOrWhiteSpace(location)) return false;
            if (location.Length < 3 || location.Length > 200) return false;

            // Allow letters, numbers, spaces, commas, and basic punctuation
            return Regex.IsMatch(location, @"^[a-zA-Z0-9\s,.-]+$");
        }

        /// <summary>
        /// Validates description - must be meaningful length and content
        /// </summary>
        /// <param name="description">Description to validate</param>
        /// <returns>True if valid, false otherwise</returns>
        public static bool IsValidDescription(string description)
        {
            if (string.IsNullOrWhiteSpace(description)) return false;
            if (description.Length < 10 || description.Length > 1000) return false;
            return true;
        }

        /// <summary>
        /// Validates file type and size for attachments
        /// </summary>
        /// <param name="filePath">Path to file to validate</param>
        /// <returns>True if valid file, false otherwise</returns>
        public static bool IsValidFile(string filePath)
        {
            try
            {
                if (!File.Exists(filePath)) return false;

                // Check file extension
                string extension = Path.GetExtension(filePath).ToLower();
                bool validExtension = false;
                foreach (string allowedExt in AllowedFileExtensions)
                {
                    if (extension == allowedExt)
                    {
                        validExtension = true;
                        break;
                    }
                }
                if (!validExtension) return false;

                // Check file size
                FileInfo fileInfo = new FileInfo(filePath);
                return fileInfo.Length <= MaxFileSizeBytes;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Gets file size in human-readable format
        /// </summary>
        /// <param name="filePath">Path to file</param>
        /// <returns>Formatted file size string</returns>
        public static string GetFileSizeString(string filePath)
        {
            try
            {
                FileInfo fileInfo = new FileInfo(filePath);
                long bytes = fileInfo.Length;

                if (bytes < 1024) return $"{bytes} bytes";
                if (bytes < 1024 * 1024) return $"{bytes / 1024:F1} KB";
                return $"{bytes / (1024 * 1024):F1} MB";
            }
            catch
            {
                return "Unknown size";
            }
            //(Microsoft, 2024 & Validation Techniques in C#, 2022)
        }
    }
}
/*
Reference List
1. Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 07 September 2025]. 
2. Validation Techniques in C#. 2022. In: Smith, J. and Lee, A. eds. Programming best practices. Johannesburg: CodePress, Chapter 7: 112-130.
*/
