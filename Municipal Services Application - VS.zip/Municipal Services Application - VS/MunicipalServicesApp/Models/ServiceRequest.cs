﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp.Models
{
    /// <summary>
    /// Represents a service request in the municipal system
    /// Links to the original Issue and tracks its status through the resolution process
    /// </summary>
    public class ServiceRequest
    {
        public int RequestId { get; set; }
        public int IssueId { get; set; }
        public string Location { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public DateTime SubmissionDate { get; set; }
        public RequestStatus Status { get; set; }
        public DateTime LastUpdated { get; set; }
        public string AssignedDepartment { get; set; }
        public int Priority { get; set; } // 1-10, where 10 is highest
        public List<string> StatusHistory { get; set; }

        // Graph relationships
        public List<int> RelatedRequests { get; set; } // Related service requests (graph edges)
        public List<int> DependsOn { get; set; } // Requests this depends on
        public List<int> Dependents { get; set; } // Requests depending on this one

        public ServiceRequest()
        {
            StatusHistory = new List<string>();
            RelatedRequests = new List<int>();
            DependsOn = new List<int>();
            Dependents = new List<int>();
            Status = RequestStatus.Submitted;
            LastUpdated = DateTime.Now;
        }

        /// <summary>
        /// Updates the status and adds to history
        /// </summary>
        public void UpdateStatus(RequestStatus newStatus)
        {
            Status = newStatus;
            LastUpdated = DateTime.Now;
            StatusHistory.Add($"{DateTime.Now:yyyy-MM-dd HH:mm}: {newStatus}");
        }
    }

    /// <summary>
    /// Possible states for a service request
    /// Used for tracking progress through the resolution workflow
    /// </summary>
    public enum RequestStatus
    {
        Submitted = 0,
        UnderReview = 1,
        Assigned = 2,
        InProgress = 3,
        OnHold = 4,
        Resolved = 5,
        Closed = 6
    }

    //(Validation Techniques in C#, 2022)
}
/*
Reference List
1. Validation Techniques in C#. 2022. In: Smith, J. and Lee, A. eds. Programming best practices. Johannesburg: CodePress, Chapter 7: 112-130.
*/
