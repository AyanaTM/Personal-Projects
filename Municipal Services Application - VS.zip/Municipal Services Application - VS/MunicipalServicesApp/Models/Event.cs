﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp.Models
{
    /// <summary>
    /// Represents a local municipal event or announcement
    /// </summary>
    public class Event
    {
        public int EventId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime EventDate { get; set; }
        public string Category { get; set; }
        public string Location { get; set; }
        public string Organizer { get; set; }
        public EventPriority Priority { get; set; }
        public HashSet<string> Tags { get; set; }
        public DateTime CreatedDate { get; set; }

        public Event()
        {
            Tags = new HashSet<string>();
            CreatedDate = DateTime.Now;
            Priority = EventPriority.Normal;
        }
        //(Validation Techniques in C#, 2022)
    }

    /// <summary>
    /// Priority levels for events (used with Priority Queue)
    /// </summary>
    public enum EventPriority
    {
        Low = 0,
        Normal = 1,
        High = 2,
        Urgent = 3
    }
    //(Validation Techniques in C#, 2022)
}
/*
Reference List
1. Validation Techniques in C#. 2022. In: Smith, J. and Lee, A. eds. Programming best practices. Johannesburg: CodePress, Chapter 7: 112-130.
*/
