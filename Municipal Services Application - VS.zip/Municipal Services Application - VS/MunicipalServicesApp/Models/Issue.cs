﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp.Models
{
    /// <summary>
    /// Represents a municipal service issue reported by a citizen
    /// </summary>
    public class Issue
    {
        public int IssueId { get; set; }
        public string Location { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public List<string> AttachmentPaths { get; set; }
        public DateTime SubmissionDate { get; set; }
        public string Status { get; set; }

        /// <summary>
        /// Constructor initializes empty attachment list and pending status
        /// </summary>
        public Issue()
        {
            AttachmentPaths = new List<string>();
            Status = "Pending";
            SubmissionDate = DateTime.Now;
        }
        //(Validation Techniques in C#, 2022)
    }
}

/*
Reference List
1. Validation Techniques in C#. 2022. In: Smith, J. and Lee, A. eds. Programming best practices. Johannesburg: CodePress, Chapter 7: 112-130.
*/
