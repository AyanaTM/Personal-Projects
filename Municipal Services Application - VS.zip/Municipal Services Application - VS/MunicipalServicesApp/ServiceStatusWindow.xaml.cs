﻿using MunicipalServicesApp.Models;
using MunicipalServicesApp.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace MunicipalServicesApp
{
    /// <summary>
    /// Service Request Status Window - demonstrates advanced data structures
    /// Implements BST, AVL, Red-Black Tree, Heap, Graph, BFS, DFS, and MST concepts
    /// 
    public partial class ServiceStatusWindow : Window
    {
        private List<ServiceRequest> currentDisplayedRequests;

        public ServiceStatusWindow()
        {
            try
            {
                InitializeComponent();
                currentDisplayedRequests = new List<ServiceRequest>();

                // Used ContentRendered instead of Loaded for better timing
                this.ContentRendered += ServiceStatusWindow_ContentRendered;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing window: {ex.Message}",
                    "Initialization Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Content rendered event - called after window and all controls are fully rendered
        /// This happens AFTER Loaded and ensures everything is ready
        /// </summary>
        private void ServiceStatusWindow_ContentRendered(object sender, EventArgs e)
        {
            try
            {
                // Removes the event handler so it only runs once
                this.ContentRendered -= ServiceStatusWindow_ContentRendered;

                // Verifies controls are initialized
                if (panelRequests == null)
                {
                    MessageBox.Show("Error: Display panel not initialized. Please restart the application.",
                        "Initialization Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    Close();
                    return;
                }

                LoadAllRequests();
                UpdateStatistics();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}\n\n{ex.StackTrace}",
                    "Load Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Loads and displays all service requests
        /// Uses various data structures for different views
        /// </summary>
        private void LoadAllRequests()
        {
            try
            {
                // Gets all requests from the manager
                currentDisplayedRequests = ServiceRequestManager.GetAllRequests();
                DisplayRequests(currentDisplayedRequests, "All Service Requests");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading requests: {ex.Message}",
                    "Load Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Searches for a specific request by ID using Binary Search Tree
        /// Demonstrates O(log n) lookup efficiency
        /// </summary>
        private void BtnSearchById_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtSearchId.Text))
                {
                    MessageBox.Show("Please enter a request ID to search.",
                        "Input Required", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                if (!int.TryParse(txtSearchId.Text, out int requestId))
                {
                    MessageBox.Show("Please enter a valid numeric request ID.",
                        "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Use BST search - O(log n) time complexity
                ServiceRequest request = ServiceRequestManager.SearchByRequestId(requestId);

                if (request != null)
                {
                    currentDisplayedRequests = new List<ServiceRequest> { request };
                    DisplayRequests(currentDisplayedRequests, $"Search Result: Request #{requestId}");

                    MessageBox.Show($"Request found!\n\nID: {request.RequestId}\n" +
                        $"Status: {request.Status}\nPriority: {request.Priority}/10",
                        "Search Successful", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    panelRequests.Children.Clear();
                    txtResultsTitle.Text = "No Results Found";
                    txtResultsCount.Text = "(0)";

                    MessageBox.Show($"No request found with ID: {requestId}",
                        "Not Found", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching request: {ex.Message}",
                    "Search Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Filters requests by status using Red-Black Tree (SortedDictionary)
        /// Demonstrates efficient status-based categorization
        /// </summary>
        private void CmbStatusFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (cmbStatusFilter.SelectedItem == null) return;

                string selected = ((ComboBoxItem)cmbStatusFilter.SelectedItem).Content.ToString();

                if (selected.Contains("All"))
                {
                    LoadAllRequests();
                    return;
                }

                // Map display text to enum
                RequestStatus status = MapStatusFromDisplay(selected);

                // Use Red-Black Tree structure for status filtering
                currentDisplayedRequests = ServiceRequestManager.GetRequestsByStatus(status);
                DisplayRequests(currentDisplayedRequests, $"Requests: {selected}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error filtering requests: {ex.Message}",
                    "Filter Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Shows urgent requests using Min-Heap structure
        /// Demonstrates O(1) access to highest priority items
        /// </summary>
        private void BtnShowUrgent_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Get most urgent request from heap
                ServiceRequest mostUrgent = ServiceRequestManager.GetMostUrgentRequest();

                if (mostUrgent != null)
                {
                    currentDisplayedRequests = new List<ServiceRequest> { mostUrgent };
                    DisplayRequests(currentDisplayedRequests, "🚨 Most Urgent Request");

                    MessageBox.Show($"Most Urgent Request:\n\n" +
                        $"ID: #{mostUrgent.RequestId}\n" +
                        $"Priority: {mostUrgent.Priority}/10\n" +
                        $"Category: {mostUrgent.Category}\n" +
                        $"Location: {mostUrgent.Location}\n\n" +
                        "This request requires immediate attention!",
                        "Urgent Request", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    MessageBox.Show("No urgent requests found in the system.",
                        "No Urgent Requests", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error retrieving urgent requests: {ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Shows all requests sorted by priority using AVL-like tree
        /// Demonstrates efficient priority-based sorting
        /// </summary>
        private void BtnShowPriority_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Get requests sorted by priority (highest first)
                currentDisplayedRequests = ServiceRequestManager.GetRequestsByPriority();
                DisplayRequests(currentDisplayedRequests, "⭐ Requests by Priority (Highest First)");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error sorting by priority: {ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Finds related requests using Graph Traversal (BFS)
        /// Demonstrates graph algorithms for relationship analysis
        /// </summary>
        private void BtnShowRelated_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtSearchId.Text))
                {
                    MessageBox.Show("Please enter a request ID first to find related requests.",
                        "Input Required", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                if (!int.TryParse(txtSearchId.Text, out int requestId))
                {
                    MessageBox.Show("Please enter a valid numeric request ID.",
                        "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Use BFS graph traversal to find related requests
                List<ServiceRequest> relatedRequests = ServiceRequestManager.FindRelatedRequests(requestId);

                if (relatedRequests.Count > 0)
                {
                    currentDisplayedRequests = relatedRequests;
                    DisplayRequests(currentDisplayedRequests, $"🔗 Requests Related to #{requestId}");

                    MessageBox.Show($"Found {relatedRequests.Count} related request(s).\n\n" +
                        "These requests are connected through:\n" +
                        "- Similar locations\n" +
                        "- Common categories\n" +
                        "- Dependency relationships\n\n" +
                        "Analysis uses Breadth-First Search (BFS) graph traversal.",
                        "Related Requests Found", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show($"No related requests found for ID: {requestId}",
                        "No Related Requests", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error finding related requests: {ex.Message}",
                    "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Displays a list of service requests in the UI
        /// Creates visual cards for each request
        /// </summary>
        private void DisplayRequests(List<ServiceRequest> requests, string title)
        {
            if (panelRequests == null)
            {
                return; // Exit if not ready yet
            }

            panelRequests.Children.Clear();
            txtResultsTitle.Text = title;
            txtResultsCount.Text = $"({requests.Count})";

            if (requests.Count == 0)
            {
                ShowNoRequestsMessage();
                return;
            }

            foreach (var request in requests)
            {
                CreateRequestCard(request);
            }
        }

        /// <summary>
        /// Creates a visual card for a service request
        /// Displays all relevant information and status
        /// </summary>
        private void CreateRequestCard(ServiceRequest request)
        {
            Border card = new Border
            {
                Background = (Brush)FindResource("White"),
                BorderBrush = GetPriorityColor(request.Priority),
                BorderThickness = new Thickness(3),
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(20),
                Margin = new Thickness(0, 0, 0, 15),
                Cursor = System.Windows.Input.Cursors.Hand
            };

            StackPanel cardContent = new StackPanel();

            // Header Row: ID, Priority, Status
            StackPanel headerRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 12)
            };

            TextBlock idBlock = new TextBlock
            {
                Text = $"Request #{request.RequestId}",
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                Foreground = (Brush)FindResource("PrimaryBlue")
            };

            Border priorityBadge = new Border
            {
                Background = GetPriorityColor(request.Priority),
                CornerRadius = new CornerRadius(15),
                Padding = new Thickness(12, 5, 12, 5),
                Margin = new Thickness(15, 0, 10, 0)
            };

            TextBlock priorityText = new TextBlock
            {
                Text = $"⭐ Priority: {request.Priority}/10",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("White")
            };
            priorityBadge.Child = priorityText;

            Border statusBadge = new Border
            {
                Background = GetStatusColor(request.Status),
                CornerRadius = new CornerRadius(15),
                Padding = new Thickness(12, 5, 12, 5)
            };

            TextBlock statusText = new TextBlock
            {
                Text = GetStatusIcon(request.Status) + " " + request.Status.ToString(),
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("White")
            };
            statusBadge.Child = statusText;

            headerRow.Children.Add(idBlock);
            headerRow.Children.Add(priorityBadge);
            headerRow.Children.Add(statusBadge);

            // Info Row: Category and Department
            StackPanel infoRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 10)
            };

            TextBlock categoryBlock = new TextBlock
            {
                Text = $"📂 {request.Category}",
                FontSize = 13,
                FontWeight = FontWeights.Medium,
                Foreground = (Brush)FindResource("SecondaryBlue"),
                Margin = new Thickness(0, 0, 20, 0)
            };

            TextBlock deptBlock = new TextBlock
            {
                Text = $"🏛️ {request.AssignedDepartment}",
                FontSize = 13,
                Foreground = (Brush)FindResource("DarkGray")
            };

            infoRow.Children.Add(categoryBlock);
            infoRow.Children.Add(deptBlock);

            // Location
            TextBlock locationBlock = new TextBlock
            {
                Text = $"📍 Location: {request.Location}",
                FontSize = 14,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("PrimaryBlue"),
                Margin = new Thickness(0, 0, 0, 10)
            };

            // Description
            TextBlock descBlock = new TextBlock
            {
                Text = request.Description,
                FontSize = 13,
                Foreground = (Brush)FindResource("DarkGray"),
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 12),
                MaxHeight = 60
            };

            // Dates Row
            StackPanel datesRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 10)
            };

            TextBlock submittedBlock = new TextBlock
            {
                Text = $"📅 Submitted: {request.SubmissionDate:yyyy-MM-dd HH:mm}",
                FontSize = 11,
                Foreground = (Brush)FindResource("DarkGray"),
                Margin = new Thickness(0, 0, 20, 0)
            };

            TextBlock updatedBlock = new TextBlock
            {
                Text = $"🔄 Updated: {request.LastUpdated:yyyy-MM-dd HH:mm}",
                FontSize = 11,
                Foreground = (Brush)FindResource("DarkGray")
            };

            datesRow.Children.Add(submittedBlock);
            datesRow.Children.Add(updatedBlock);

            // Related Requests Info
            if (request.RelatedRequests.Count > 0)
            {
                TextBlock relatedBlock = new TextBlock
                {
                    Text = $"🔗 {request.RelatedRequests.Count} related request(s)",
                    FontSize = 11,
                    Foreground = (Brush)FindResource("AccentGreen"),
                    FontStyle = FontStyles.Italic,
                    Margin = new Thickness(0, 5, 0, 0)
                };
                cardContent.Children.Add(relatedBlock);
            }

            // Dependencies Info
            if (request.DependsOn.Count > 0)
            {
                TextBlock dependsBlock = new TextBlock
                {
                    Text = $"⚠️ Depends on {request.DependsOn.Count} other request(s)",
                    FontSize = 11,
                    Foreground = (Brush)FindResource("WarningOrange"),
                    FontStyle = FontStyles.Italic,
                    Margin = new Thickness(0, 3, 0, 0)
                };
                cardContent.Children.Add(dependsBlock);
            }

            cardContent.Children.Add(headerRow);
            cardContent.Children.Add(infoRow);
            cardContent.Children.Add(locationBlock);
            cardContent.Children.Add(descBlock);
            cardContent.Children.Add(datesRow);

            card.Child = cardContent;

            // Add click event to show details
            card.MouseLeftButtonDown += (s, e) => ShowRequestDetails(request);

            panelRequests.Children.Add(card);
        }

        /// <summary>
        /// Shows detailed information about a request
        /// Includes status history and graph relationships
        /// </summary>
        private void ShowRequestDetails(ServiceRequest request)
        {
            string details = $"SERVICE REQUEST DETAILS\n\n" +
                $"Request ID: #{request.RequestId}\n" +
                $"Linked Issue ID: #{request.IssueId}\n" +
                $"Status: {request.Status}\n" +
                $"Priority: {request.Priority}/10\n\n" +
                $"Category: {request.Category}\n" +
                $"Department: {request.AssignedDepartment}\n" +
                $"Location: {request.Location}\n\n" +
                $"Description:\n{request.Description}\n\n" +
                $"Submitted: {request.SubmissionDate:yyyy-MM-dd HH:mm}\n" +
                $"Last Updated: {request.LastUpdated:yyyy-MM-dd HH:mm}\n\n";

            if (request.StatusHistory.Count > 0)
            {
                details += "STATUS HISTORY:\n";
                foreach (var history in request.StatusHistory)
                {
                    details += $"  • {history}\n";
                }
                details += "\n";
            }

            if (request.RelatedRequests.Count > 0)
            {
                details += $"RELATED REQUESTS: {string.Join(", ", request.RelatedRequests.Select(r => $"#{r}"))}\n";
            }

            if (request.DependsOn.Count > 0)
            {
                details += $"DEPENDS ON: {string.Join(", ", request.DependsOn.Select(r => $"#{r}"))}\n";
            }

            if (request.Dependents.Count > 0)
            {
                details += $"BLOCKING: {string.Join(", ", request.Dependents.Select(r => $"#{r}"))}\n";
            }

            MessageBox.Show(details, "Request Details", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        /// <summary>
        /// Shows message when no requests are found
        /// </summary>
        private void ShowNoRequestsMessage()
        {
            Border messageCard = new Border
            {
                Background = (Brush)FindResource("LightGray"),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(30),
                Margin = new Thickness(0, 20, 0, 0)
            };

            StackPanel messagePanel = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center
            };

            TextBlock titleBlock = new TextBlock
            {
                Text = "📭 No Requests Found",
                FontSize = 18,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("DarkGray"),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10)
            };

            TextBlock descBlock = new TextBlock
            {
                Text = "No service requests match your current filters.",
                FontSize = 14,
                Foreground = (Brush)FindResource("DarkGray"),
                TextAlignment = TextAlignment.Center
            };

            messagePanel.Children.Add(titleBlock);
            messagePanel.Children.Add(descBlock);
            messageCard.Child = messagePanel;

            panelRequests.Children.Add(messageCard);
        }

        /// <summary>
        /// Updates statistics display
        /// </summary>
        private void UpdateStatistics()
        {
            try
            {
                var stats = ServiceRequestManager.GetStatistics();
                txtTotalRequests.Text = stats["TotalRequests"].ToString();
                txtUrgentRequests.Text = stats["UrgentRequests"].ToString();
                txtPendingRequests.Text = stats["PendingRequests"].ToString();
                txtInProgressRequests.Text = stats["InProgressRequests"].ToString();
                txtResolvedRequests.Text = stats["ResolvedRequests"].ToString();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error updating statistics: {ex.Message}");
            }
        }

        /// <summary>
        /// Refresh button handler
        /// </summary>
        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadAllRequests();
            UpdateStatistics();
            MessageBox.Show("Data refreshed successfully!", "Refresh Complete",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        /// <summary>
        /// Clear filters button handler
        /// </summary>
        private void BtnClearFilter_Click(object sender, RoutedEventArgs e)
        {
            txtSearchId.Clear();
            cmbStatusFilter.SelectedIndex = 0;
            LoadAllRequests();
        }

        /// <summary>
        /// Back button handler
        /// </summary>
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        // Helper methods for colors and icons

        private Brush GetPriorityColor(int priority)
        {
            if (priority >= 9) return (Brush)FindResource("ErrorRed");
            if (priority >= 7) return (Brush)FindResource("WarningOrange");
            if (priority >= 5) return (Brush)FindResource("SecondaryBlue");
            return (Brush)FindResource("DarkGray");
        }

        private Brush GetStatusColor(RequestStatus status)
        {
            switch (status)
            {
                case RequestStatus.Submitted:
                case RequestStatus.UnderReview:
                    return (Brush)FindResource("WarningOrange");
                case RequestStatus.Assigned:
                case RequestStatus.InProgress:
                    return (Brush)FindResource("SecondaryBlue");
                case RequestStatus.OnHold:
                    return (Brush)FindResource("DarkGray");
                case RequestStatus.Resolved:
                case RequestStatus.Closed:
                    return (Brush)FindResource("AccentGreen");
                default:
                    return (Brush)FindResource("DarkGray");
            }
        }

        private string GetStatusIcon(RequestStatus status)
        {
            switch (status)
            {
                case RequestStatus.Submitted: return "📝";
                case RequestStatus.UnderReview: return "👀";
                case RequestStatus.Assigned: return "✅";
                case RequestStatus.InProgress: return "🔧";
                case RequestStatus.OnHold: return "⏸️";
                case RequestStatus.Resolved: return "✔️";
                case RequestStatus.Closed: return "📋";
                default: return "📄";
            }
        }

        private RequestStatus MapStatusFromDisplay(string display)
        {
            if (display.Contains("Submitted")) return RequestStatus.Submitted;
            if (display.Contains("Under Review")) return RequestStatus.UnderReview;
            if (display.Contains("Assigned")) return RequestStatus.Assigned;
            if (display.Contains("In Progress")) return RequestStatus.InProgress;
            if (display.Contains("On Hold")) return RequestStatus.OnHold;
            if (display.Contains("Resolved")) return RequestStatus.Resolved;
            if (display.Contains("Closed")) return RequestStatus.Closed;
            return RequestStatus.Submitted;
        }
    }
}

/*
References:
- Jamro, M. 2018. C# Data Structures and Algorithms. Birmingham: Packt Publishing. Chapters 5-6.
- Nakov, S. et al. 2013. Fundamentals of Computer Programming with C#. Sofia: Svetlin Nakov. Chapters 17, 19.
- Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 03 November 2025].
- Municipal Services Guide. 2023. Community engagement strategies for municipal improvement. Cape Town: Municipal Services Publishing.
*/