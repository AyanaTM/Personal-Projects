Municipal Services Application
Portfolio of Evidence (POE) Part 2

This repository contains the source code for Part 2 of the Municipal Services Application, developed as part of the Programming 3B (PROG7312) Portfolio of Evidence. This application builds upon Part 1 by adding advanced event management functionality using sophisticated data structures and algorithms.
Project Overview

Part 2 of this application introduces the "Local Events and Announcements" functionality, which extends the municipal services platform. Users can now:
•	Browse local events and announcements organised by date and category
•	Search and filter events using multiple criteria (category, date, search terms)
•	View priority events that require immediate attention
•	Receive personalised event recommendations based on search history and interests
•	Access detailed event information including location, organiser, and tags
•	Continue reporting municipal issues (from Part 1)

The application demonstrates advanced programming concepts including:
•	SortedDictionary for chronological event organisation
•	Dictionary for fast category-based lookups
•	HashSet for unique categories and tags
•	Priority Queue (via SortedSet) for urgent announcements
•	Stack for search history tracking (LIFO)
•	Queue for event notifications (FIFO)
•	Recommendation Algorithm based on user behaviour patterns

The application is built using C# and Windows Presentation Foundation (WPF) within the .NET Framework.

Getting Started

Follow these instructions to set up, build, and run the project on your local machine.

Prerequisites

Before you begin, ensure you have the following software installed:
a.	Visual Studio 2019 or later: 
This project is developed using Visual Studio. You can download the Community edition (which is free for students and individual developers) from the official Microsoft website.
•	Download Visual Studio

b.	.NET Framework 4.7.2 or later: 
Ensure that the .NET desktop development workload is selected during Visual Studio installation, as this typically includes the necessary .NET Framework components.

How to Open the Project in Visual Studio

a.	Clone the Repository (Recommended): 
If you have Git installed, open your terminal or Git Bash and run:
git clone https://github.com/VCPTA/bca3-prog7312-part-2-submission-ST10375530.git 

b.	Download as ZIP: 
Alternatively, you can download the project as a ZIP file from the GitHub repository page by clicking the "Code" button and then "Download ZIP". Extract the contents to your desired location.

c. Open in Visual Studio:
•	Navigate to the cloned or extracted project folder.
•	Locate the solution file: MunicipalServicesApp.sln.
•	Double-click MunicipalServicesApp.sln to open the project directly in Visual Studio.
•	Alternatively, open Visual Studio, go to File > Open > Project/Solution..., and browse to the MunicipalServicesApp.sln file.

How to Build/Compile the Project

Once the project is open in Visual Studio:

a.	Restore NuGet Packages (if prompted): 
Visual Studio should automatically restore any required NuGet packages when you open the solution. If not, or if you encounter build errors related to missing references, right-click on the MunicipalServicesApp solution in the Solution Explorer and select Restore NuGet Packages.

b.	Clean Solution (Optional but Recommended): 
To ensure a clean build, it's often good practice to clean the solution first.
•	In the Visual Studio menu, go to Build > Clean Solution.

c.	Build Solution:
•	In the Visual Studio menu, go to Build > Build Solution.
•	Alternatively, you can press F6 on your keyboard.

d. Check Output:
•	Monitor the "Output" window (usually at the bottom of Visual Studio) for build progress and any errors.
•	A successful build will display "Build succeeded" in the Output window.

How to Run and Use the Software

After successfully building the project:

Running the Application – 

a.	Run the Application:
•	In the Visual Studio menu, go to Debug > Start Debugging.
•	Alternatively, you can press F5 on your keyboard.
•	You can also run without debugging by going to Debug > Start Without Debugging or pressing Ctrl + F5.

Using the Application – 

b.	Main Menu: 
Upon startup, you will see the "Municipal Services Portal" main window with three service options:
•	"Report Municipal Issues" button (active - from Part 1)
•	"Local Events and Announcements" button (NOW ACTIVE - Part 2)
•	"Service Request Status" button (disabled - coming in Part 3)
•	Community engagement statistics display showing "Total Community Reports" and "Reports Today"

Viewing Local Events and Announcements (NEW in Part 2) – 

c.	Accessing Events:
1.	Click the "View Events" button under "Local Events and Announcements"
2.	The "Local Events and Announcements" window will open

d.	Browsing Events:
•	All Events Display: Upon opening, you'll see a list of upcoming municipal events organised chronologically
•	Event Cards: Each event displays: 
o	Event title and description
o	Date and time
o	Category badge (color-coded)
o	Priority indicator (for urgent events)
o	Location and organiser information
o	Relevant tags

e.	Searching Events:
1.	Search Box:
Enter keywords in the search box at the top:
o	Searches across event titles, descriptions, locations, and tags
o	Real-time results as you type

2.	Category Filter: 
Use the category dropdown to filter by specific event types: 
o	Community Development
o	Water & Sanitation
o	Roads & Infrastructure
o	Government & Administration
o	Health & Safety
o	Sports & Recreation
o	Electricity & Utilities
o	Economic Development
o	Arts & Culture
o	Public Safety

3.	Date Filter: Select a specific date using the date picker to view events on that day
4.	Combined Filters: Use search terms, category, and date together for precise results

f.	Recommendations Section:
•	Personalised Recommendations: Based on your search history, the application suggests relevant events

•	Smart Algorithm: The recommendation system analyses: 
o	Your search patterns
o	Category preferences
o	Tag interests
o	Upcoming event proximity
o	Event priority levels
•	Dynamic Updates: Recommendations update as you search and interact with events

g.	Priority Events:
•	Urgent Announcements: High-priority and urgent events are highlighted
•	Quick Access: Priority events appear at the top of filtered results
•	Visual Indicators: Special badges identify priority levels

h.	Search History:
•	The application tracks your recent searches (using a Stack data structure)
•	This history informs the recommendation algorithm
•	Helps you quickly find similar events in the future

Advanced Data Structures in Action

The Local Events and Announcements feature demonstrates several advanced data structures:

1.	SortedDictionary<DateTime, List<Event>>
o	Events automatically sorted by date
o	Efficient date-range queries
o	O(log n) insertion and lookup

2.	Dictionary<string, List<Event>>
o	Fast category-based filtering
o	O(1) lookup time for categories
o	Instant category switching

3.	HashSet<string>
o	Unique categories and tags
o	No duplicate values
o	Efficient membership testing

4.	Priority Queue (via SortedSet<Event>)
o	Urgent events automatically prioritised
o	Custom comparer for priority ordering
o	Quick access to high-priority items

5.	Stack<string>
o	Search history (LIFO - Last In, First Out)
o	Most recent searches easily accessible
o	Used for recommendation analysis

6.	Queue<Event>
o	Event notification system (FIFO - First In, First Out)
o	Sequential processing of new events
o	Fair notification ordering

Reporting Municipal Issues (from Part 1)

i.	Reporting an Issue:
1.	Click the "Start Reporting" button under "Report Municipal Issues"
2.	A new "Report Municipal Issue" window will appear
3.	Location: Enter the location of the issue (e.g., "123 Main Street, Suburbia")
4.	Issue Category: Select a category from the dropdown list (e.g., "Roads and Infrastructure", "Water and Sanitation")
5.	Detailed Description: Provide a detailed explanation of the issue in the text area. A character counter will guide you
6.	Attachments (Optional): Click "Attach File" to add photos or documents. You can select multiple files. If you select a file, it will appear in the list below. You can select an attached file and click "Remove Selected" to remove it
7.	Community Impact: Observe the "Community Impact Level" progress bar and the dynamic "Community Impact" message, which changes based on your selected category
8.	Validation: If you miss any required fields or enter invalid data, validation errors will appear at the bottom of the form
9.	Submit Report: Click "Submit Report" to finalize and submit your issue. A confirmation message with a reference number will be displayed
10.	Clear Form: Click "Clear Form" to reset all fields on the form
11.	Back to Menu: Click "Back to Menu" to return to the main application window. If you have unsaved changes, you will be prompted to confirm

j.	Viewing Reported Issues:
•	After submitting issues, the "Total Community Reports" and "Reports Today" counters on the main window will update
•	The full issue list functionality displays all submitted reports with their status

Key Features and Technical Implementation

Data Structure Usage – 
1.	Event Organisation:
o	Events stored in SortedDictionary<DateTime, List<Event>> for automatic chronological sorting
o	Category index maintained in Dictionary<string, List<Event>> for O(1) category lookups
o	Unique categories tracked in HashSet<string> for efficient filtering options

2.	Search and Filtering:
o	Multi-criteria search across title, description, location, and tags
o	Efficient date-range queries using SortedDictionary properties
o	Category filtering with instant Dictionary lookups

3.	Priority Management:
o	Priority Queue implemented using SortedSet<Event> with custom EventPriorityComparer
o	Urgent and high-priority events automatically sorted to top
o	Priority levels: Low (0), Normal (1), High (2), Urgent (3)

4.	User Engagement:
o	Search history tracked using Stack (LIFO) for pattern analysis
o	Notification queue using Queue (FIFO) for fair event updates
o	Recommendation algorithm analyses user behaviour patterns
o	
Recommendation Algorithm – 

The application includes an intelligent recommendation system that:
1.	Analyses Search Patterns:
o	Tracks user search terms in a Stack
o	Identifies category and tag preferences
o	Weights recent searches higher

2.	Scoring System:
o	Category match: +10 points per search match
o	Tag match: +5 points per search match
o	Priority bonus: +3 points × priority level
o	Upcoming event bonus: +15 points for events within 7 days

3.	Recommendation Display:
o	Top 5 recommended events shown
o	Sorted by calculated score
o	Updated dynamically as user searches

Sample Data – 

The application includes 10 pre-loaded sample events covering various categories:
•	Community Clean-Up Day (Community Development)
•	Water Conservation Workshop (Water & Sanitation)
•	Road Maintenance Notice (Roads & Infrastructure)
•	Municipal Budget Meeting (Government & Administration)
•	Free Health Screening (Health & Safety)
•	Youth Sports Tournament (Sports & Recreation)
•	Electricity Load Shedding Schedule Update (Electricity & Utilities)
•	Small Business Development Workshop (Economic Development)
•	Heritage Day Celebration (Arts & Culture)
•	Public Safety Awareness Campaign (Public Safety)

Application Architecture

Project Structure – 
MunicipalServicesApp/
├── MainWindow.xaml / .xaml.cs          (Main menu and navigation)
├── ReportIssueWindow.xaml / .xaml.cs   (Issue reporting from Part 1)
├── EventsWindow.xaml / .xaml.cs        (NEW: Events display and search)
├── IssueListWindow.xaml / .xaml.cs     (Issue list view)
├── Models/
│   ├── Issue.cs                        (Issue data model)
│   └── Event.cs                        (NEW: Event data model with Priority enum)
├── Services/
│   ├── DataManager.cs                  (Issue data management)
│   └── EventManager.cs                 (NEW: Event management with advanced data structures)
├── Utils/
│   └── ValidationHelper.cs             (Input validation utilities)
├── App.xaml / .xaml.cs                 (Application resources and startup)
└── AssemblyInfo.cs                     (Assembly configuration)

Key Classes and Components – 

Event Model (Models/Event.cs):
•	Properties: EventId, Title, Description, EventDate, Category, Location, Organiser, Priority, Tags, CreatedDate
•	EventPriority enum: Low, Normal, High, Urgent

EventManager Service (Services/EventManager.cs):
•	Static class managing all event-related operations
•	Implements all required data structures: 
o	SortedDictionary for date-based organisation
o	Dictionary for category indexing
o	HashSet for unique categories/tags
o	SortedSet for priority queue
o	Stack for search history
o	Queue for notifications
•	Methods: 
o	AddEvent() - Add new events to all data structures
o	GetAllEvents() - Retrieve chronologically sorted events
o	GetEventsByCategory() - Fast category filtering
o	GetEventsByDateRange() - Efficient date range queries
o	SearchEvents() - Multi-criteria search with recommendations
o	GetRecommendedEvents() - Intelligent event suggestions
o	GetPriorityEvents() - High-priority event access

EventPriorityComparer (Services/EventManager.cs):
•	Custom IComparer<Event> implementation
•	Sorts by: Priority (descending) → Date (ascending) → EventId (ascending)
•	Ensures unique ordering in SortedSet

Code Quality and Best Practices

The application demonstrates:
1.	Comprehensive XML Documentation:
o	All methods and classes documented
o	Clear parameter and return value descriptions
o	Usage examples where appropriate

2.	Error Handling:
o	Try-catch blocks for file operations and data access
o	User-friendly error messages
o	Graceful degradation

3.	Data Structure Efficiency:
o	Appropriate structure selection for each use case
o	O(1) lookups where possible
o	Efficient sorting and filtering

4.	User Experience:
o	Real-time search results
o	Visual feedback for all actions
o	Intuitive navigation
o	Color-coded categories and priorities

5.	Code Organisation:
o	Clear separation of concerns (Models, Services, Utils)
o	Static managers for shared data
o	Consistent naming conventions

Testing the Advanced Features

To verify the advanced data structures and algorithms are working:
1.	SortedDictionary: Events display in chronological order automatically
2.	Dictionary: Category filtering responds instantly (no delay)
3.	HashSet: No duplicate categories in the dropdown, all tags unique
4.	Priority Queue: Priority events section shows highest priority items first
5.	Stack: Perform several searches and check recommendations update based on history
6.	Queue: (Internal) New events processed in order added
7.	Recommendation Algorithm: Search for specific terms and see related events suggested

Known Limitations

•	Events are stored in memory only (data persists only during application runtime)
•	Maximum of 1000 search history items retained in Stack
•	Recommendation algorithm limited to analysing last 100 searches for performance

Future Enhancements (Part 3)

The next phase will implement:
•	Service Request Status tracking
•	Real-time status updates
•	Administrative dashboard
•	Persistent data storage
•	Enhanced reporting and analytics

Contact

For any questions or issues regarding this project, please contact:
Student Number: ST10375530
Name: Ayana Modise

References
 	Microsoft. 2024. Windows Presentation Foundation (WPF). [Online]. Available at: https://docs.microsoft.com/en-us/dotnet/desktop/wpf/ [Accessed 07 October 2025].
 	Jamro, M. 2018. C# Data Structures and Algorithms. Birmingham: Packt Publishing. Chapters 2-4.
 	Nakov, S. et al. 2013. Fundamentals of Computer Programming with C#. Sofia: Svetlin Nakov. Chapters 10, 14, 16, 19, 20.
 	Hart, T.G.B., et al. 2020. Innovation for Development in South Africa: Experiences with Basic Service Technologies in Distressed Municipalities. Forum for Development Studies, 47(1): 23-47.
 	Municipal Services Guide. 2023. Community engagement strategies for municipal improvement. Cape Town: Municipal Services Publishing.

