// script.js
// General purpose JavaScript for HustleHub

// You could add functions here like:
// - Toggle navigation menu on mobile
// - Handle form submissions (client-side validation)
// - Dynamic loading of content (e.g., more listings)
// - Interactive map for service locations
// - Notification handling

document.addEventListener('DOMContentLoaded', () => {
    console.log("HustleHub App Loaded!");
    // Any global initializations can go here
});
