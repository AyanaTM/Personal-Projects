﻿using Microsoft.EntityFrameworkCore;
using ST10375530_CLDV6211_PART3.Models;

namespace ST10375530_CLDV6211_PART3.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Venue> Venue { get; set; }
        public DbSet<Event> Event { get; set; }
        public DbSet<Customer> Customer { get; set; }
        public DbSet<Booking> Booking { get; set; }
        public DbSet<EventType> EventType { get; set; }
        public DbSet<EventStatus> EventStatus { get; set; } 

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure relationship between Venue and Event
            modelBuilder.Entity<Event>()
                .HasOne(e => e.Venue)
                .WithMany(v => v.Event)
                .HasForeignKey(e => e.VenueId);

            // Configure relationship between Booking and Event
            modelBuilder.Entity<Booking>()
                .HasOne(b => b.Event)
                .WithMany(e => e.Booking)
                .HasForeignKey(b => b.EventId);

            // Configure relationship between Booking and Venue
            modelBuilder.Entity<Booking>()
                .HasOne(b => b.Venue)
                .WithMany(v => v.Booking)
                .HasForeignKey(b => b.VenueId);

            // Configure relationship between Booking and Customer
            modelBuilder.Entity<Booking>()
                .HasOne(b => b.Customer)
                .WithMany(c => c.Booking)
                .HasForeignKey(b => b.CustomerId);

            // Configure relationship between Event and EventType
            modelBuilder.Entity<Event>()
                .HasOne(e => e.EventType)
                .WithMany()
                .HasForeignKey(e => e.EventTypeId);

            // Configure relationship between Event and EventStatus
            modelBuilder.Entity<Event>()
                .HasOne(e => e.EventStatus)
                .WithMany()
                .HasForeignKey(e => e.EventStatusId);
        }
        //(Khan, 2023 & Mrzyglod, 2022 & tdykstra, 2022)
    }
}
//Reference List:
//Khan, M. 2023. Entity Framework Code First Approach: Display Data from Database in ASP.NET MVC, ASPSnippets, 14 January 2023. [Online]. Available at: https://www.aspsnippets.com/Articles/3860/Entity-Framework-Code-First-Approach-Display-Data-from-Database-in-ASPNet-MVC/ [Accessed 05 April 2025].
//Mrzyglod, K. 2022. Azure for Developers: Implement rich Azure PaaS ecosystems using containers, serverless services, and storage solutions. 2nd Ed. Birmingham: Packt Publishing.
//tdykstra. 2022. Creating an Entity Framework Data Model for an ASP.NET MVC Application (1 of 10), Microsoft, 01 July 2022. [Online]. Available at: https://learn.microsoft.com/en-us/aspnet/mvc/overview/older-versions/getting-started-with-ef-5-using-mvc-4/creating-an-entity-framework-data-model-for-an-asp-net-mvc-application [Accessed 05 April 2025].

