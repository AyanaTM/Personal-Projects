﻿using System.ComponentModel.DataAnnotations;

namespace ST10375530_CLDV6211_PART3.Models
{
    public class EventType
    {
        public int EventTypeId { get; set; }
        [Required]
        [StringLength(100)]
        [Display(Name = "Event Type")]
        public string TypeName { get; set; }
        public string Description { get; set; }
        //(Khan, 2023 & Mrzyglod, 2022 & tdykstra, 2022)
    }
}
//Reference List:
//Khan, M. 2023. Entity Framework Code First Approach: Display Data from Database in ASP.NET MVC, ASPSnippets, 14 January 2023. [Online]. Available at: https://www.aspsnippets.com/Articles/3860/Entity-Framework-Code-First-Approach-Display-Data-from-Database-in-ASPNet-MVC/ [Accessed 05 April 2025].
//Mrzyglod, K. 2022. Azure for Developers: Implement rich Azure PaaS ecosystems using containers, serverless services, and storage solutions. 2nd Ed. Birmingham: Packt Publishing.
//tdykstra. 2022. Creating an Entity Framework Data Model for an ASP.NET MVC Application (1 of 10), Microsoft, 01 July 2022. [Online]. Available at: https://learn.microsoft.com/en-us/aspnet/mvc/overview/older-versions/getting-started-with-ef-5-using-mvc-4/creating-an-entity-framework-data-model-for-an-asp-net-mvc-application [Accessed 05 April 2025].

