﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Azure.Storage.Blobs;
using Microsoft.EntityFrameworkCore;
using ST10375530_CLDV6211_PART3.Data;
using ST10375530_CLDV6211_PART3.Models;
using Microsoft.Extensions.Configuration;

namespace ST10375530_CLDV6211_PART3.Controllers
{
    public class VenueController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly string _storageConnectionString;

        public VenueController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _storageConnectionString = configuration.GetConnectionString("AzureBlobStorage");
        }

        // Method to upload image to Azure Blob Storage
        private async Task<string> UploadImage(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return null;

            var blobServiceClient = new BlobServiceClient(_storageConnectionString);
            var containerClient = blobServiceClient.GetBlobContainerClient("venue-images");
            await containerClient.CreateIfNotExistsAsync(); 

            string blobName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
            var blobClient = containerClient.GetBlobClient(blobName);

            using (var stream = file.OpenReadStream())
            {
                await blobClient.UploadAsync(stream);
            }

            return blobClient.Uri.ToString(); // Return the URL of the uploaded image
        }

        // GET: Venues
        public async Task<IActionResult> Index()
        {
            return View(await _context.Venue.ToListAsync());
        }

        // GET: Venues/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var venue = await _context.Venue
                .FirstOrDefaultAsync(m => m.VenueId == id);
            if (venue == null)
            {
                return NotFound();
            }

            return View(venue);
        }

        // GET: Venues/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Venues/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        // Include ImageFile in the Bind attribute for correct model binding of the uploaded file
        public async Task<IActionResult> Create([Bind("VenueId,VenueName,Location,Capacity,ImageFile")] Venue venue)
        {
            if (ModelState.IsValid)
            {
                if (venue.ImageFile != null)
                {
                    venue.ImageUrl = await UploadImage(venue.ImageFile);
                }

                _context.Add(venue);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            // If ModelState is not valid, the errors will be displayed on the form.
            return View(venue);
        }

        // GET: Venues/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var venue = await _context.Venue.FindAsync(id);
            if (venue == null)
            {
                return NotFound();
            }
            return View(venue);
        }

        // POST: Venues/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        // Ensure ImageFile and ImageUrl are in the Bind attribute
        public async Task<IActionResult> Edit(int id, [Bind("VenueId,VenueName,Location,Capacity,ImageFile,ImageUrl")] Venue venue)
        {
            if (id != venue.VenueId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Fetch the existing venue entity from the database without tracking
                    // This is crucial to avoid issues when updating with a new entity
                    var existingVenue = await _context.Venue.AsNoTracking().FirstOrDefaultAsync(v => v.VenueId == id);
                    if (existingVenue == null)
                    {
                        return NotFound();
                    }

                    // If a new image file is provided, upload it and update ImageUrl
                    if (venue.ImageFile != null)
                    {
                        venue.ImageUrl = await UploadImage(venue.ImageFile);
                    }
                    else
                    {
                        // If no new image file, retain the existing ImageUrl from the database
                        // This prevents ImageUrl from becoming null if no new file is selected
                        venue.ImageUrl = existingVenue.ImageUrl;
                    }

                    // Mark the venue entity as modified. If you fetched existingVenue without AsNoTracking
                    _context.Update(venue);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VenueExists(venue.VenueId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            // If ModelState is not valid, the errors will be displayed on the form.
            return View(venue);
        }

        // GET: Venues/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var venue = await _context.Venue
                .FirstOrDefaultAsync(m => m.VenueId == id);
            if (venue == null)
            {
                return NotFound();
            }

            // Check if the venue has any associated bookings 
            var hasAssociatedBookings = await _context.Booking.AnyAsync(b => b.VenueId == venue.VenueId);
            if (hasAssociatedBookings)
            {
                ModelState.AddModelError("", "This venue cannot be deleted because it has associated bookings.");
                // Return the view with the error message
                return View(venue);
            }

            return View(venue);
        }

        // POST: Venues/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var venue = await _context.Venue.FindAsync(id);
            if (venue == null)
            {
                return NotFound();
            }

            // Re-check for associated bookings to prevent database constraint violation
            var hasAssociatedBookings = await _context.Booking.AnyAsync(b => b.VenueId == venue.VenueId);
            if (hasAssociatedBookings)
            {
                ModelState.AddModelError("", "Cannot delete venue with existing bookings.");
                // Return to the delete confirmation view with the error message
                return View(venue); 
            }

            _context.Venue.Remove(venue);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool VenueExists(int id)
        {
            return _context.Venue.Any(e => e.VenueId == id);
        }
    }
    //(Khan, 2023 & Mrzyglod, 2022 & tdykstra, 2022)
}
//Reference List: 
//Khan, M. 2023. Entity Framework Code First Approach: Display Data from Database in ASP.NET MVC, ASPSnippets, 14 January 2023. [Online]. Available at: https://www.aspsnippets.com/Articles/3860/Entity-Framework-Code-First-Approach-Display-Data-from-Database-in-ASPNet-MVC/ [Accessed 05 April 2025].
//Mrzyglod, K. 2022. Azure for Developers: Implement rich Azure PaaS ecosystems using containers, serverless services, and storage solutions. 2nd Ed. Birmingham: Packt Publishing.
//risha... 2020. Basic CRUD (Create, Read, Update, Delete) in ASP.NET MVC Using C# and Entity Framework, GeeksforGeeks, 25 August 2022. [Online]. Available at: https://www.geeksforgeeks.org/basic-crud-create-read-update-delete-in-asp-net-mvc-using-c-sharp-and-entity-framework/ [Accessed 05 April 2025].
//tdykstra. 2022. Creating an Entity Framework Data Model for an ASP.NET MVC Application (1 of 10), Microsoft, 01 July 2022. [Online]. Available at: https://learn.microsoft.com/en-us/aspnet/mvc/overview/older-versions/getting-started-with-ef-5-using-mvc-4/creating-an-entity-framework-data-model-for-an-asp-net-mvc-application [Accessed 05 April 2025].


