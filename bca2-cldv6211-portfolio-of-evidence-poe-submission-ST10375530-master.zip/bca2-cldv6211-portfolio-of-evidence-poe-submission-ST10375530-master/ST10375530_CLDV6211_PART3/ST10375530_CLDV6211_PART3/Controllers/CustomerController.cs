﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ST10375530_CLDV6211_PART3.Data;
using ST10375530_CLDV6211_PART3.Models;

namespace ST10375530_CLDV6211_PART3.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CustomerController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            return View(await _context.Customer.ToListAsync());
        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customer
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CustomerId,FirstName,LastName,Email,Phone")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            // If ModelState is not valid, the form will reappear with validation errors.
            // The asp-validation-summary and asp-validation-for tags in the view will display these.
            return View(customer);
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customer.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }

        // POST: Customers/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CustomerId,FirstName,LastName,Email,Phone")] Customer customer)
        {
            if (id != customer.CustomerId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.CustomerId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            // If ModelState is not valid, the form will reappear with validation errors.
            // The asp-validation-summary and asp-validation-for tags in the view will display these.
            return View(customer);
        }

        // GET: Customers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customer
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            // Check for associated bookings
            var hasAssociatedBookings = await _context.Booking.AnyAsync(b => b.CustomerId == customer.CustomerId);
            if (hasAssociatedBookings)
            {
                ModelState.AddModelError("", "This customer cannot be deleted because they have associated bookings.");
                return View(customer); // Return the view with the error message
            }

            return View(customer);
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var customer = await _context.Customer.FindAsync(id);
            if (customer == null)
            {
                return NotFound(); // Customer not found, probably already deleted or invalid ID
            }

            // Re-check for associated bookings to prevent database constraint violation
            var hasAssociatedBookings = await _context.Booking.AnyAsync(b => b.CustomerId == customer.CustomerId);
            if (hasAssociatedBookings)
            {
                ModelState.AddModelError("", "Cannot delete customer with existing bookings.");
                return View(customer); // Return to the delete confirmation view with the error message
            }

            _context.Customer.Remove(customer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CustomerExists(int id)
        {
            return _context.Customer.Any(e => e.CustomerId == id);
        }
    }
    //(Khan, 2023 & Mrzyglod, 2022 & tdykstra, 2022)
}
//Reference List: 
//Khan, M. 2023. Entity Framework Code First Approach: Display Data from Database in ASP.NET MVC, ASPSnippets, 14 January 2023. [Online]. Available at: https://www.aspsnippets.com/Articles/3860/Entity-Framework-Code-First-Approach-Display-Data-from-Database-in-ASPNet-MVC/ [Accessed 05 April 2025].
//Mrzyglod, K. 2022. Azure for Developers: Implement rich Azure PaaS ecosystems using containers, serverless services, and storage solutions. 2nd Ed. Birmingham: Packt Publishing.
//risha... 2020. Basic CRUD (Create, Read, Update, Delete) in ASP.NET MVC Using C# and Entity Framework, GeeksforGeeks, 25 August 2022. [Online]. Available at: https://www.geeksforgeeks.org/basic-crud-create-read-update-delete-in-asp-net-mvc-using-c-sharp-and-entity-framework/ [Accessed 05 April 2025].
//tdykstra. 2022. Creating an Entity Framework Data Model for an ASP.NET MVC Application (1 of 10), Microsoft, 01 July 2022. [Online]. Available at: https://learn.microsoft.com/en-us/aspnet/mvc/overview/older-versions/getting-started-with-ef-5-using-mvc-4/creating-an-entity-framework-data-model-for-an-asp-net-mvc-application [Accessed 05 April 2025].


