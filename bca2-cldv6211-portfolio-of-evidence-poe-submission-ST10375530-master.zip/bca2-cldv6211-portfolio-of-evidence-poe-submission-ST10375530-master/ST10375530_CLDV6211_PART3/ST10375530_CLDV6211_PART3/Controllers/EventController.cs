﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ST10375530_CLDV6211_PART3.Data;
using ST10375530_CLDV6211_PART3.Models;

namespace ST10375530_CLDV6211_PART3.Controllers
{
    public class EventController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EventController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Events
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Event
                                        .Include(e => e.Venue)
                                        .Include(e => e.EventType)
                                        .Include(e => e.EventStatus);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Events/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var @event = await _context.Event
                .Include(e => e.Venue)
                .Include(e => e.EventType) // Include EventType for display in details if needed
                .Include(e => e.EventStatus) // Include EventStatus for display in details if needed
                .FirstOrDefaultAsync(m => m.EventId == id);
            if (@event == null)
            {
                return NotFound();
            }

            return View(@event);
        }

        // GET: Events/Create
        public IActionResult Create()
        {
            //Populate all necessary ViewData for dropdowns for the Create view
            ViewData["VenueId"] = new SelectList(_context.Venue, "VenueId", "VenueName");
            ViewData["EventTypeId"] = new SelectList(_context.EventType, "EventTypeId", "TypeName");
            ViewData["EventStatusId"] = new SelectList(_context.EventStatus, "StatusId", "StatusName");
            return View();
        }

        // POST: Events/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EventId,EventName,EventDate,Description,VenueId,EventTypeId,EventStatusId")] Event @event)
        {
            if (ModelState.IsValid)
            {
                _context.Add(@event);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            //Repopulate ViewData if ModelState is not valid, so dropdowns work on error
            ViewData["VenueId"] = new SelectList(_context.Venue, "VenueId", "VenueName", @event.VenueId);
            ViewData["EventTypeId"] = new SelectList(_context.EventType, "EventTypeId", "TypeName", @event.EventTypeId);
            ViewData["EventStatusId"] = new SelectList(_context.EventStatus, "StatusId", "StatusName", @event.EventStatusId);
            return View(@event);
        }

        // GET: Events/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var @event = await _context.Event.FindAsync(id);
            if (@event == null)
            {
                return NotFound();
            }
            //Populate all necessary ViewData for dropdowns for the Edit view
            ViewData["VenueId"] = new SelectList(_context.Venue, "VenueId", "VenueName", @event.VenueId);
            ViewData["EventTypeId"] = new SelectList(_context.EventType, "EventTypeId", "TypeName", @event.EventTypeId);
            ViewData["EventStatusId"] = new SelectList(_context.EventStatus, "StatusId", "StatusName", @event.EventStatusId);
            return View(@event);
        }

        // POST: Events/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        //Include EventTypeId and EventStatusId in Bind attribute for Edit POST
        public async Task<IActionResult> Edit(int id, [Bind("EventId,EventName,EventDate,Description,VenueId,EventTypeId,EventStatusId")] Event @event)
        {
            if (id != @event.EventId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(@event);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EventExists(@event.EventId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            //Repopulate ViewData if ModelState is not valid, so dropdowns work on error
            ViewData["VenueId"] = new SelectList(_context.Venue, "VenueId", "VenueName", @event.VenueId);
            ViewData["EventTypeId"] = new SelectList(_context.EventType, "EventTypeId", "TypeName", @event.EventTypeId);
            ViewData["EventStatusId"] = new SelectList(_context.EventStatus, "StatusId", "StatusName", @event.EventStatusId);
            return View(@event);
        }

        // GET: Events/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var @event = await _context.Event
                .Include(e => e.Venue)
                .Include(e => e.EventType) //Display on delete confirmation page
                .Include(e => e.EventStatus) //Display on delete confirmation page
                .FirstOrDefaultAsync(m => m.EventId == id);
            if (@event == null)
            {
                return NotFound();
            }

            // Check if the event has any associated bookings 
            var hasAssociatedBookings = await _context.Booking.AnyAsync(b => b.EventId == @event.EventId);
            if (hasAssociatedBookings)
            {
                ModelState.AddModelError("", "This event cannot be deleted because it has associated bookings.");
                return View(@event);
            }

            return View(@event);
        }

        // POST: Events/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var @event = await _context.Event.FindAsync(id);
            if (@event == null)
            {
                return NotFound();
            }

            // Re-check for associated bookings to prevent database constraint violation
            var hasAssociatedBookings = await _context.Booking.AnyAsync(b => b.EventId == @event.EventId);
            if (hasAssociatedBookings)
            {
                ModelState.AddModelError("", "Cannot delete event with existing bookings.");
                return View(@event);
            }

            _context.Event.Remove(@event);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EventExists(int id)
        {
            return _context.Event.Any(e => e.EventId == id);
        }
    }
    //(Khan, 2023 & Mrzyglod, 2022 & tdykstra, 2022)
}
//Reference List: 
//Khan, M. 2023. Entity Framework Code First Approach: Display Data from Database in ASP.NET MVC, ASPSnippets, 14 January 2023. [Online]. Available at: https://www.aspsnippets.com/Articles/3860/Entity-Framework-Code-First-Approach-Display-Data-from-Database-in-ASPNet-MVC/ [Accessed 05 April 2025].
//Mrzyglod, K. 2022. Azure for Developers: Implement rich Azure PaaS ecosystems using containers, serverless services, and storage solutions. 2nd Ed. Birmingham: Packt Publishing.
//risha... 2020. Basic CRUD (Create, Read, Update, Delete) in ASP.NET MVC Using C# and Entity Framework, GeeksforGeeks, 25 August 2022. [Online]. Available at: https://www.geeksforgeeks.org/basic-crud-create-read-update-delete-in-asp-net-mvc-using-c-sharp-and-entity-framework/ [Accessed 05 April 2025].
//tdykstra. 2022. Creating an Entity Framework Data Model for an ASP.NET MVC Application (1 of 10), Microsoft, 01 July 2022. [Online]. Available at: https://learn.microsoft.com/en-us/aspnet/mvc/overview/older-versions/getting-started-with-ef-5-using-mvc-4/creating-an-entity-framework-data-model-for-an-asp-net-mvc-application [Accessed 05 April 2025].


