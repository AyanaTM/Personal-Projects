﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ST10375530_CLDV6211_PART3.Data;
using ST10375530_CLDV6211_PART3.Models;
using Microsoft.EntityFrameworkCore;
using Azure.Storage.Blobs; 
using Microsoft.Extensions.Configuration; 

namespace ST10375530_CLDV6211_PART3.Controllers
{
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Bookings
        public async Task<IActionResult> Index(string searchString, int? eventTypeId, DateTime? startDate, DateTime? endDate)
        {
            // Populate ViewBag.EventTypes for the dropdown filter in the view
            ViewBag.EventTypes = await _context.EventType.ToListAsync();

            var bookings = _context.Booking.Include(b => b.Customer)
                                           .Include(b => b.Event)
                                               .ThenInclude(e => e.EventType) // Include EventType within Event for filtering display
                                           .Include(b => b.Venue)
                                           .AsQueryable();

            if (!string.IsNullOrEmpty(searchString))
            {
                bookings = bookings.Where(b => b.Event.EventName.Contains(searchString) ||
                                                b.BookingId.ToString().Contains(searchString));
            }

            if (eventTypeId.HasValue)
            {
                bookings = bookings.Where(b => b.Event.EventTypeId == eventTypeId);
            }

            //Comparison only on Date part for date range filters
            if (startDate.HasValue)
            {
                bookings = bookings.Where(b => b.BookingDate.Date >= startDate.Value.Date);
            }
            if (endDate.HasValue)
            {
                bookings = bookings.Where(b => b.BookingDate.Date <= endDate.Value.Date);
            }

            return View(await bookings.ToListAsync());
        }

        // GET: Bookings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var booking = await _context.Booking
                .Include(b => b.Customer)
                .Include(b => b.Event)
                    .ThenInclude(e => e.EventType) 
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(m => m.BookingId == id);
            if (booking == null)
            {
                return NotFound();
            }

            return View(booking);
        }

        // GET: Bookings/Create
        public IActionResult Create()
        {
            // Populate ViewData for dropdowns when rendering the Create form
            ViewData["CustomerId"] = new SelectList(_context.Customer, "CustomerId", "FullName");
            ViewData["EventId"] = new SelectList(_context.Event, "EventId", "EventName");
            ViewData["VenueId"] = new SelectList(_context.Venue, "VenueId", "VenueName");
            return View();
        }

        // POST: Bookings/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BookingId,EventId,VenueId,BookingDate,CustomerId")] Booking booking)
        {
            if (ModelState.IsValid)
            {
                // Check for double booking using only the date part
                bool isDoubleBooked = await _context.Booking
                    .AnyAsync(b => b.VenueId == booking.VenueId && b.BookingDate.Date == booking.BookingDate.Date);

                if (isDoubleBooked)
                {
                    ModelState.AddModelError("", "This venue is already booked for the selected date.");
                    // Repopulate ViewData if ModelState is not valid
                    PopulateViewData(booking); // Use the helper method
                    return View(booking);
                }
                else
                {
                    _context.Add(booking);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            }
            // If ModelState is not valid (e.g., due to client-side issues or missing required fields), repopulate ViewData
            PopulateViewData(booking); // Use the helper method
            return View(booking);
        }

        // GET: Bookings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var booking = await _context.Booking.FindAsync(id);
            if (booking == null)
            {
                return NotFound();
            }
            //Call PopulateViewData before returning the view
            PopulateViewData(booking);
            return View(booking);
        }

        // POST: Bookings/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookingId,EventId,VenueId,BookingDate,CustomerId")] Booking booking)
        {
            if (id != booking.BookingId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                // Re-check for double booking during edit, excluding the current booking being edited
                bool isDoubleBooked = await _context.Booking
                    .AnyAsync(b => b.BookingId != booking.BookingId && // Exclude the current booking
                                   b.VenueId == booking.VenueId &&
                                   b.BookingDate.Date == booking.BookingDate.Date);

                if (isDoubleBooked)
                {
                    ModelState.AddModelError("", "This venue is already booked for the selected date.");
                    // Repopulate ViewData if error occurs
                    PopulateViewData(booking);
                    return View(booking);
                }

                try
                {
                    _context.Update(booking);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookingExists(booking.BookingId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            // Repopulate ViewData if ModelState is not valid
            PopulateViewData(booking);
            return View(booking);
        }

        // GET: Bookings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var booking = await _context.Booking
                .Include(b => b.Customer)
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(m => m.BookingId == id);
            if (booking == null)
            {
                return NotFound();
            }

            return View(booking);
        }

        // POST: Bookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var booking = await _context.Booking.FindAsync(id);
            if (booking != null)
            {
                _context.Booking.Remove(booking);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookingExists(int id)
        {
            return _context.Booking.Any(e => e.BookingId == id);
        }

        // Helper method to populate common ViewData for dropdowns
        private void PopulateViewData(Booking booking)
        {
            ViewData["CustomerId"] = new SelectList(_context.Customer, "CustomerId", "FullName", booking.CustomerId);
            ViewData["EventId"] = new SelectList(_context.Event, "EventId", "EventName", booking.EventId);
            ViewData["VenueId"] = new SelectList(_context.Venue, "VenueId", "VenueName", booking.VenueId);
        }
    }
    //(Khan, 2023 & Mrzyglod, 2022 & tdykstra, 2022)
}
//Reference List: 
//Khan, M. 2023. Entity Framework Code First Approach: Display Data from Database in ASP.NET MVC, ASPSnippets, 14 January 2023. [Online]. Available at: https://www.aspsnippets.com/Articles/3860/Entity-Framework-Code-First-Approach-Display-Data-from-Database-in-ASPNet-MVC/ [Accessed 05 April 2025].
//Mrzyglod, K. 2022. Azure for Developers: Implement rich Azure PaaS ecosystems using containers, serverless services, and storage solutions. 2nd Ed. Birmingham: Packt Publishing.
//risha... 2020. Basic CRUD (Create, Read, Update, Delete) in ASP.NET MVC Using C# and Entity Framework, GeeksforGeeks, 25 August 2022. [Online]. Available at: https://www.geeksforgeeks.org/basic-crud-create-read-update-delete-in-asp-net-mvc-using-c-sharp-and-entity-framework/ [Accessed 05 April 2025].
//tdykstra. 2022. Creating an Entity Framework Data Model for an ASP.NET MVC Application (1 of 10), Microsoft, 01 July 2022. [Online]. Available at: https://learn.microsoft.com/en-us/aspnet/mvc/overview/older-versions/getting-started-with-ef-5-using-mvc-4/creating-an-entity-framework-data-model-for-an-asp-net-mvc-application [Accessed 05 April 2025].

