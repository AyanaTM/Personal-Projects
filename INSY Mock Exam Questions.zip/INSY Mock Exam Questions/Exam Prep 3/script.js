document.addEventListener('DOMContentLoaded', () => {
    const submitExamBtn = document.getElementById('submitExamBtn');
    const showAnswersBtn = document.getElementById('showAnswersBtn');
    const answerKeySection = document.getElementById('answerKey');

    // Simulate exam submission
    submitExamBtn.addEventListener('click', () => {
        alert('Exam Submitted! (This is a simulated submission. You can now use the "Show Answers" button for self-correction.)');
        // You could add logic here to collect answers if this were a real interactive test
        // For self-assessment, an alert is sufficient.
    });

    // Toggle visibility of the answer key
    showAnswersBtn.addEventListener('click', () => {
        if (answerKeySection.classList.contains('hidden')) {
            answerKeySection.classList.remove('hidden');
            showAnswersBtn.textContent = 'Hide Answers';
            // Scroll to the answer key section for better UX
            answerKeySection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } else {
            answerKeySection.classList.add('hidden');
            showAnswersBtn.textContent = 'Show Answers';
        }
    });

    // Optional: Auto-capitalize matching inputs
    document.querySelectorAll('.match-input').forEach(input => {
        input.addEventListener('input', () => {
            input.value = input.value.toUpperCase();
        });
    });
});