using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ST10375530_SOEN6222_POE_Final.Pages.Volunteer
{
    public class ScheduleModel : PageModel
    {
        public List<Shift> AvailableShifts { get; set; }

        public void OnGet()
        {
            AvailableShifts = new List<Shift>
        {
            new Shift { Id = 1, Date = DateTime.Now, Time = "09:00 AM - 12:00 PM", Location = "Community Center" },
            new Shift { Id = 2, Date = DateTime.Now.AddDays(1), Time = "01:00 PM - 04:00 PM", Location = "Park" }
        };
        }

        public class Shift
        {
            public int Id { get; set; }
            public DateTime Date { get; set; }
            public string Time { get; set; }
            public string Location { get; set; }
        }
    }
}

