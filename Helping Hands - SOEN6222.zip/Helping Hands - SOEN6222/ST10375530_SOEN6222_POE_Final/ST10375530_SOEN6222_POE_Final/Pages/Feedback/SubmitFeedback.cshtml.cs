using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ST10375530_SOEN6222_POE_Final.Pages.Feedback
{
    public class SubmitFeedbackModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
