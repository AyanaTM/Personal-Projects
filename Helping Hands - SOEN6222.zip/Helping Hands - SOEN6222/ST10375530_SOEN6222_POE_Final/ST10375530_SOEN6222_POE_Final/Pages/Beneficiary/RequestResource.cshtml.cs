using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ST10375530_SOEN6222_POE_Final.Pages.Beneficiary
{
    public class RequestResourceModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
