using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ST10375530_SOEN6222_POE_Final.Pages.Admin
{
    public class InventoryModel : PageModel
    {
        public List<InventoryItem> InventoryItems { get; set; }

        public void OnGet()
        {
            InventoryItems = new List<InventoryItem>
        {
            new InventoryItem { Id = 1, Name = "Blankets", Stock = 50, LowStockAlert = false },
            new InventoryItem { Id = 2, Name = "Canned Food", Stock = 10, LowStockAlert = true }
        };
        }

        public class InventoryItem
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public int Stock { get; set; }
            public bool LowStockAlert { get; set; }
        }
    }
}
