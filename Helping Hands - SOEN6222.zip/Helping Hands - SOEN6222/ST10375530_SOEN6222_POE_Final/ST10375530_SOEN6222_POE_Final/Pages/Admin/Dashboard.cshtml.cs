using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ST10375530_SOEN6222_POE_Final.Pages.Admin
{
    public class DashboardModel : PageModel
    {
        // Simple properties with hardcoded or calculated values
        public int InventoryCount { get; set; } = 150; // Example value
        public int RecentVolunteerShifts { get; set; } = 25; // Example value
        public int RecentDonations { get; set; } = 10; // Example value

        public void OnGet()
        {
        }
    }
}

