using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ST10375530_SOEN6222_POE_Final.Pages.Account
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
